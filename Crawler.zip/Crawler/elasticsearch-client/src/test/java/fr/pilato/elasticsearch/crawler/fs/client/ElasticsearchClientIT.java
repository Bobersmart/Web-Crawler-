/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.client;

import com.carrotsearch.randomizedtesting.jupiter.RandomizedTest;
import com.jayway.jsonpath.DocumentContext;
import fr.pilato.elasticsearch.crawler.fs.beans.Doc;
import fr.pilato.elasticsearch.crawler.fs.framework.ExponentialBackoffPollInterval;
import fr.pilato.elasticsearch.crawler.fs.framework.FsCrawlerUtil;
import fr.pilato.elasticsearch.crawler.fs.framework.JsonUtil;
import fr.pilato.elasticsearch.crawler.fs.framework.bulk.FsCrawlerBulkResponse;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettingsLoader;
import fr.pilato.elasticsearch.crawler.fs.test.framework.AbstractFSCrawlerTestCase;
import fr.pilato.elasticsearch.crawler.fs.test.framework.DisabledIfNoDocker;
import fr.pilato.elasticsearch.crawler.fs.test.framework.Nightly;
import fr.pilato.elasticsearch.crawler.fs.test.framework.Slow;
import fr.pilato.elasticsearch.crawler.fs.test.framework.TestContainerHelper;
import fr.pilato.elasticsearch.crawler.fs.test.framework.VerySlow;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;
import javax.net.ssl.SSLHandshakeException;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Assumptions;
import org.assertj.core.api.InstanceOfAssertFactories;
import org.awaitility.Awaitility;
import org.awaitility.core.ConditionTimeoutException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.testcontainers.containers.wait.strategy.HttpWaitStrategy;
import org.testcontainers.nginx.NginxContainer;
import org.testcontainers.utility.MountableFile;

@Slow
class ElasticsearchClientIT extends AbstractFSCrawlerTestCase {
    private static final Logger logger = LogManager.getLogger();
    private static final String DEFAULT_TEST_CLUSTER_URL = "https://127.0.0.1:9200";
    private static final String DEFAULT_USERNAME = "elastic";
    private static final TestContainerHelper TEST_CONTAINER_HELPER = new TestContainerHelper();

    private static String testClusterUrl = getSystemProperty("tests.cluster.url", DEFAULT_TEST_CLUSTER_URL);
    private static final boolean TEST_CHECK_CERTIFICATE = getSystemProperty("tests.cluster.check_ssl", true);
    private static final boolean TEST_KEEP_DATA = getSystemProperty("tests.leaveTemporary", true);
    protected static String testApiKey = getSystemProperty("tests.cluster.apiKey", null);
    private static String testCaCertificate;
    private static ElasticsearchClient esClient;

    private static Duration maxWaitForSearch;

    @BeforeAll
    static void startServices(Random rnd) throws IOException, ElasticsearchClientException {
        logger.debug("Generate settings against [{}] with ssl check [{}]", testClusterUrl, TEST_CHECK_CERTIFICATE);

        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.getElasticsearch().setUrls(List.of(testClusterUrl));
        fsSettings.getElasticsearch().setSslVerification(TEST_CHECK_CERTIFICATE);
        fsSettings.getElasticsearch().setCaCertificate(testCaCertificate);
        if (testApiKey != null) {
            fsSettings.getElasticsearch().setApiKey(testApiKey);
        } else {
            fsSettings.getElasticsearch().setUsername(DEFAULT_USERNAME);
            fsSettings.getElasticsearch().setPassword(TestContainerHelper.DEFAULT_PASSWORD);
        }

        try {
            esClient = startClient(fsSettings);
        } catch (ElasticsearchClientException e) {
            if (e.getCause() instanceof ProcessingException
                    && e.getCause().getCause() instanceof SSLHandshakeException
                    && fsSettings.getElasticsearch().isSslVerification()) {
                logger.fatal(
                        "❌ SSL check is on but you are probably using a self-signed certificate on [{}]."
                                + " You can bypass this SSL check using -Dtests.cluster.check_ssl=false",
                        fsSettings.getElasticsearch().getUrls().get(0));
                throw e;
            }

            if (!DEFAULT_TEST_CLUSTER_URL.equals(testClusterUrl)) {
                logger.fatal(
                        "❌ Can not connect to Elasticsearch on [{}] with ssl checks [{}]. You can "
                                + "disable it using -Dtests.cluster.check_ssl=false",
                        testClusterUrl,
                        TEST_CHECK_CERTIFICATE);
                throw e;
            }
            if (TEST_CONTAINER_HELPER.isStarted()) {
                logger.fatal(
                        "❌ Elasticsearch TestContainer was previously started but we can not connect to it "
                                + "on [{}] with ssl checks [{}].",
                        testClusterUrl,
                        TEST_CHECK_CERTIFICATE);
                logger.fatal("Full error:", e);
                throw e;
            }

            logger.debug("Elasticsearch is not running on [{}]. We switch to TestContainer.", testClusterUrl);
            testClusterUrl = TEST_CONTAINER_HELPER.startElasticsearch(TEST_KEEP_DATA);
            // Write the Ca Certificate on disk if exists (with versions < 8, no self-signed certificate)
            if (TEST_CONTAINER_HELPER.getCertAsBytes() != null) {
                Path clusterCaCrtPath = Files.createTempFile("fscrawler-ca-", ".crt");
                Files.write(clusterCaCrtPath, TEST_CONTAINER_HELPER.getCertAsBytes());
                testCaCertificate = clusterCaCrtPath.toAbsolutePath().toString();
            } else {
                testCaCertificate = null;
            }
            fsSettings.getElasticsearch().setUrls(List.of(testClusterUrl));
            fsSettings.getElasticsearch().setSslVerification(testCaCertificate != null);
            fsSettings.getElasticsearch().setCaCertificate(testCaCertificate);
            esClient = startClient(fsSettings);
        }

        Assumptions.assumeThat(esClient)
                .as("Integration tests are skipped because we have not been able to find an Elasticsearch cluster")
                .isNotNull();

        // If the Api Key is not provided, we want to generate it and use in all the tests
        if (testApiKey == null) {
            // Generate the Api-Key
            testApiKey = esClient.generateApiKey("fscrawler-" + RandomizedTest.randomAsciiAlphanumOfLength(rnd, 10));

            fsSettings.getElasticsearch().setApiKey(testApiKey);
            fsSettings.getElasticsearch().setUsername(null);
            fsSettings.getElasticsearch().setPassword(null);

            // Close the previous client
            esClient.close();

            // Start a new client with the Api Key
            esClient = startClient(fsSettings);
        }

        String version = esClient.getVersion();
        logger.info("✅ Starting integration tests against an external cluster running elasticsearch [{}]", version);

        if (esClient.isSemanticSupported()) {
            maxWaitForSearch = MAX_WAIT_FOR_SEARCH_LONG_TESTS;
            logger.info(
                    "Semantic search is supported on this cluster. We will give {} to run the tests.",
                    maxWaitForSearch);
        } else {
            maxWaitForSearch = MAX_WAIT_FOR_SEARCH;
            logger.info(
                    "Semantic search is not supported on this cluster. We will give {} to run the tests.",
                    maxWaitForSearch);
        }
    }

    private static ElasticsearchClient startClient(FsSettings fsSettings) throws ElasticsearchClientException {
        logger.debug(
                "Starting a client against [{}] with [{}] as a CA certificate and ssl check [{}]",
                fsSettings.getElasticsearch().getUrls().get(0),
                fsSettings.getElasticsearch().getCaCertificate(),
                fsSettings.getElasticsearch().isSslVerification());
        ElasticsearchClient client = new ElasticsearchClient(fsSettings);
        client.start();
        return client;
    }

    @AfterAll
    static void stopServices() throws IOException {
        logger.debug("Stopping integration tests against an external cluster");
        if (esClient != null) {
            esClient.close();
            esClient = null;
            logger.debug("Elasticsearch client stopped");
        }
        testCaCertificate = null;
    }

    /** Minimal settings carrying this test's index/folder names, to drive template cleanup by exact name. */
    private FsSettings cleanupSettings() {
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.setName(getCrawlerName());
        fsSettings.getElasticsearch().setIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        fsSettings.getElasticsearch().setIndexFolder(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_FOLDER);
        return fsSettings;
    }

    @BeforeEach
    void cleanExistingIndex() throws ElasticsearchClientException {
        logger.debug("🧹 Removing existing index [{}*]", getCrawlerName());
        esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_FOLDER);

        // Remove existing templates by their exact names (mirroring what the crawler creates) so a
        // wildcard cannot delete a prefix-sibling test's templates under parallel execution.
        logger.debug("🧹 Removing existing index and component templates for [{}]", getCrawlerName());
        esClient.removeIndexAndComponentTemplates(cleanupSettings());

        // Ingest pipelines created by tests use getCrawlerName() as the pipeline id.
        logger.debug("🧹 Removing existing ingest pipeline [{}]", getCrawlerName());
        esClient.deletePipeline(getCrawlerName());

        logger.info("🎬 Starting test [{}] with [{}] as the crawler name", jobName, getCrawlerName());
    }

    @AfterEach
    void cleanUp() throws ElasticsearchClientException {
        if (!TEST_KEEP_DATA) {
            logger.debug("🧹 Removing index [{}*]", getCrawlerName());
            esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
            esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_FOLDER);
            // Remove the templates this test may have created, by their exact names.
            esClient.removeIndexAndComponentTemplates(cleanupSettings());
            esClient.deletePipeline(getCrawlerName());
        }

        logger.info("✅ End of test [{}] with [{}] as the crawler name", jobName, getCrawlerName());
    }

    @Test
    void deleteIndex() throws ElasticsearchClientException {
        esClient.deleteIndex("does-not-exist-index");
        createIndex();
        Assertions.assertThat(esClient.isExistingIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS))
                .isTrue();
        esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        Assertions.assertThat(esClient.isExistingIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS))
                .isFalse();
    }

    @Test
    void waitForHealthyIndex() throws ElasticsearchClientException {
        createIndex();
        esClient.waitForHealthyIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);

        // This one could take a long time as the index does not exist
        Assertions.assertThatNoException().isThrownBy(() -> esClient.waitForHealthyIndex("does-not-exist-index"));
    }

    @Test
    void refresh() throws ElasticsearchClientException {
        createIndex();
        Assertions.assertThatNoException()
                .isThrownBy(() -> esClient.refresh(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS));
    }

    @Test
    void removeIndexAndComponentTemplatesLeavesNoLeftover() throws Exception {
        // A dedicated client whose settings carry this test's own index/folder names, so
        // createIndexAndComponentTemplates() and removeIndexAndComponentTemplates() agree.
        FsSettings settings = FsSettingsLoader.load();
        settings.getElasticsearch().setUrls(List.of(testClusterUrl));
        settings.getElasticsearch().setSslVerification(false);
        settings.getElasticsearch().setApiKey(testApiKey);
        settings.getElasticsearch().setIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        settings.getElasticsearch().setIndexFolder(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_FOLDER);
        settings.getElasticsearch().setPushTemplates(true);
        settings.getElasticsearch().setSemanticSearch(false);
        settings.getFs().setIndexFolders(true);

        ElasticsearchClient localClient = startClient(settings);
        try {
            localClient.createIndexAndComponentTemplates();

            // Everything create() produced must now exist.
            for (String name : ElasticsearchClient.componentTemplateNames(settings)) {
                Assertions.assertThat(localClient.isExistingComponentTemplate(name))
                        .as("component template [%s] should exist after create", name)
                        .isTrue();
            }
            for (String name : ElasticsearchClient.indexTemplateNames(settings)) {
                Assertions.assertThat(localClient.isExistingIndexTemplate(name))
                        .as("index template [%s] should exist after create", name)
                        .isTrue();
            }

            // After removal, nothing must be left over.
            localClient.removeIndexAndComponentTemplates(settings);
            for (String name : ElasticsearchClient.componentTemplateNames(settings)) {
                Assertions.assertThat(localClient.isExistingComponentTemplate(name))
                        .as("component template [%s] should be gone after remove", name)
                        .isFalse();
            }
            for (String name : ElasticsearchClient.indexTemplateNames(settings)) {
                Assertions.assertThat(localClient.isExistingIndexTemplate(name))
                        .as("index template [%s] should be gone after remove", name)
                        .isFalse();
            }
        } finally {
            localClient.removeIndexAndComponentTemplates(settings);
            localClient.close();
        }
    }

    private void createSearchDataset() throws Exception {
        createIndex("""
                {
                  "mappings": {
                    "properties": {
                      "foo": {
                        "properties": {
                          "bar": {
                            "type": "text",
                            "store": true,
                            "fields": {
                              "raw": {
                                "type":  "keyword"
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }""");

        esClient.indexSingle(
                getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "1", "{ \"foo\": { \"bar\": \"bar\" } }", null);
        esClient.indexSingle(
                getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "2", "{ \"foo\": { \"bar\": \"baz\" } }", null);
        esClient.indexSingle(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "3", "{ \"number\": 1 }", null);
        esClient.indexSingle(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "4", "{ \"number\": 2 }", null);

        // Wait until we have 4 documents indexed
        countTestHelper(new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS), 4L);
    }

    @Test
    void searchMatchAll() throws Exception {
        createSearchDataset();

        ESSearchResponse response =
                esClient.search(new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(4L);

        for (ESSearchHit hit : response.getHits()) {
            Assertions.assertThat(hit.getIndex()).isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
            Assertions.assertThat(hit.getId()).containsAnyOf("1", "2", "3", "4");
            Assertions.assertThat(hit.getVersion()).isEqualTo(1L);
            Assertions.assertThat(hit.getSource()).isNotEmpty();
            Assertions.assertThat(hit.getHighlightFields()).isEmpty();
            Assertions.assertThat(hit.getStoredFields()).isNull();
        }
    }

    @Test
    void searchTerm() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESTermQuery("foo.bar", "bar")));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getIndex())
                .isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        Assertions.assertThat(response.getHits().get(0).getId()).isEqualTo("1");
        Assertions.assertThat(response.getHits().get(0).getVersion()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getSource()).isNotEmpty();
        Assertions.assertThat(response.getHits().get(0).getHighlightFields()).isEmpty();
        Assertions.assertThat(response.getHits().get(0).getStoredFields()).isNull();
    }

    @Test
    void searchMatch() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESMatchQuery("foo.bar", "bar")));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getIndex())
                .isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        Assertions.assertThat(response.getHits().get(0).getId()).isEqualTo("1");
        Assertions.assertThat(response.getHits().get(0).getVersion()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getSource()).isNotEmpty();
        Assertions.assertThat(response.getHits().get(0).getHighlightFields()).isEmpty();
        Assertions.assertThat(response.getHits().get(0).getStoredFields()).isNull();
    }

    @Test
    void searchPrefix() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESPrefixQuery("foo.bar", "ba")));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(2L);

        for (ESSearchHit hit : response.getHits()) {
            Assertions.assertThat(hit.getIndex()).isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
            Assertions.assertThat(hit.getId()).containsAnyOf("1", "2");
            Assertions.assertThat(hit.getVersion()).isEqualTo(1L);
            Assertions.assertThat(hit.getSource()).isNotEmpty();
            Assertions.assertThat(hit.getHighlightFields()).isEmpty();
            Assertions.assertThat(hit.getStoredFields()).isNull();
        }
    }

    @Test
    void searchRangeLowerThan() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESRangeQuery("number").withLt(2)));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getIndex())
                .isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        Assertions.assertThat(response.getHits().get(0).getId()).isEqualTo("3");
        Assertions.assertThat(response.getHits().get(0).getVersion()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getSource()).isNotEmpty();
        Assertions.assertThat(response.getHits().get(0).getHighlightFields()).isEmpty();
        Assertions.assertThat(response.getHits().get(0).getStoredFields()).isNull();
    }

    @Test
    void searchRangeGreaterOrEqual() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESRangeQuery("number").withGte(2)));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getIndex())
                .isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        Assertions.assertThat(response.getHits().get(0).getId()).isEqualTo("4");
        Assertions.assertThat(response.getHits().get(0).getVersion()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getSource()).isNotEmpty();
        Assertions.assertThat(response.getHits().get(0).getHighlightFields()).isEmpty();
        Assertions.assertThat(response.getHits().get(0).getStoredFields()).isNull();
    }

    @Test
    void searchBoolWithPrefixAndMatch() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESBoolQuery()
                        .addMust(new ESPrefixQuery("foo.bar", "ba"))
                        .addMust(new ESMatchQuery("foo.bar", "bar"))));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getIndex())
                .isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        Assertions.assertThat(response.getHits().get(0).getId()).isEqualTo("1");
        Assertions.assertThat(response.getHits().get(0).getVersion()).isEqualTo(1L);
        Assertions.assertThat(response.getHits().get(0).getSource()).isNotEmpty();
        Assertions.assertThat(response.getHits().get(0).getHighlightFields()).isEmpty();
        Assertions.assertThat(response.getHits().get(0).getStoredFields()).isNull();
    }

    @Test
    void searchHighlighting() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESMatchQuery("foo.bar", "bar"))
                .addHighlighter("foo.bar"));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(1L);
        Assertions.assertThat(response.getHits()).singleElement().satisfies(hit -> {
            Assertions.assertThat(hit.getIndex()).isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
            Assertions.assertThat(hit.getId()).isEqualTo("1");
            Assertions.assertThat(hit.getVersion()).isEqualTo(1L);
            Assertions.assertThat(hit.getSource()).isNotEmpty();
            Assertions.assertThat(hit.getHighlightFields())
                    .hasSize(1)
                    .containsKey("foo.bar")
                    .extractingByKey("foo.bar", InstanceOfAssertFactories.list(String.class))
                    .singleElement()
                    .isEqualTo("<em>bar</em>");
            Assertions.assertThat(hit.getStoredFields()).isNull();
        });
    }

    @Test
    void searchFields() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESPrefixQuery("foo.bar", "ba"))
                .addStoredField("foo.bar"));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(2L);

        for (ESSearchHit hit : response.getHits()) {
            Assertions.assertThat(hit.getIndex()).isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
            Assertions.assertThat(hit.getId()).containsAnyOf("1", "2");
            Assertions.assertThat(hit.getVersion()).isEqualTo(1L);
            Assertions.assertThat(hit.getSource()).isNullOrEmpty();
            Assertions.assertThat(hit.getHighlightFields()).isEmpty();
            Assertions.assertThat(hit.getStoredFields()).isNotNull();
            Assertions.assertThat(hit.getStoredFields())
                    .extractingByKey("foo.bar")
                    .satisfies(storedField -> Assertions.assertThat(storedField).containsAnyOf("bar", "baz"));
        }
    }

    @Test
    void searchFieldsWithSource() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withESQuery(new ESPrefixQuery("foo.bar", "ba"))
                .addStoredField("_source")
                .addStoredField("foo.bar"));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(2L);

        for (ESSearchHit hit : response.getHits()) {
            Assertions.assertThat(hit.getIndex()).isEqualTo(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
            Assertions.assertThat(hit.getId()).containsAnyOf("1", "2");
            Assertions.assertThat(hit.getVersion()).isEqualTo(1L);
            Assertions.assertThat(hit.getSource()).isNotEmpty();
            Assertions.assertThat(hit.getHighlightFields()).isEmpty();
            Assertions.assertThat(hit.getStoredFields()).isNotNull();
            Assertions.assertThat(hit.getStoredFields())
                    .extractingByKey("foo.bar")
                    .satisfies(storedField -> Assertions.assertThat(storedField).containsAnyOf("bar", "baz"));
        }
    }

    @Test
    void searchAggregations() throws Exception {
        createSearchDataset();

        ESSearchResponse response = esClient.search(new ESSearchRequest()
                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                .withAggregation(new ESTermsAggregation("foobar1", "foo.bar.raw"))
                .withAggregation(new ESTermsAggregation("foobar2", "foo.bar.raw"))
                .withSize(0));
        Assertions.assertThat(response.getTotalHits()).isEqualTo(4L);
        Assertions.assertThat(response.getAggregations()).isNotNull();
        Assertions.assertThat(response.getAggregations()).hasSize(2);
        Assertions.assertThat(response.getAggregations()).containsKey("foobar1");
        Assertions.assertThat(response.getAggregations().get("foobar1").getName())
                .isEqualTo("foobar1");
        Assertions.assertThat(response.getAggregations().get("foobar1").getBuckets())
                .hasSize(2);
        Assertions.assertThat(response.getAggregations().get("foobar1").getBuckets())
                .contains(
                        new ESTermsAggregation.ESTermsBucket("bar", 1), new ESTermsAggregation.ESTermsBucket("baz", 1));
        Assertions.assertThat(response.getAggregations()).containsKey("foobar2");
        Assertions.assertThat(response.getAggregations().get("foobar2").getName())
                .isEqualTo("foobar2");
        Assertions.assertThat(response.getAggregations().get("foobar2").getBuckets())
                .hasSize(2);
        Assertions.assertThat(response.getAggregations().get("foobar2").getBuckets())
                .contains(
                        new ESTermsAggregation.ESTermsBucket("bar", 1), new ESTermsAggregation.ESTermsBucket("baz", 1));
    }

    @Test
    void findVersion() throws ElasticsearchClientException {
        String version = esClient.getVersion();
        logger.info("Current elasticsearch version: [{}]", version);

        // If we did not use an external URL but the docker instance we can test for sure that the version is the
        // expected one
        if (System.getProperty("tests.cluster.url") == null) {
            Properties properties = FsCrawlerUtil.readPropertiesFromClassLoader("elasticsearch.version.properties");
            Assertions.assertThat(version).isEqualTo(properties.getProperty("version"));
        }
    }

    @Test
    void pipeline() throws ElasticsearchClientException {
        String crawlerName = getCrawlerName();

        // Create an empty ingest pipeline
        String pipeline = """
                {
                  "description": "Testing Grok on PDF upload",
                  "processors": [
                    {
                      "gsub": {
                        "field": "content",
                        "pattern": "\\n",
                        "replacement": "-"
                      }
                    },
                    {
                      "grok": {
                        "field": "content",
                        "patterns": [
                          "%{DATA}%{IP:ip_addr} %{GREEDYDATA}"
                        ]
                      }
                    }
                  ]
                }""";
        esClient.createPipeline(crawlerName, pipeline);

        Assertions.assertThat(esClient.isExistingPipeline(crawlerName)).isTrue();
        Assertions.assertThat(esClient.isExistingPipeline(crawlerName + "_foo")).isFalse();
    }

    @Test
    void bulk_index_only() throws Exception {
        long nbItems = RandomizedTest.randomLongInRange(randomizedRandomForTests, 5, 20);

        ElasticsearchBulkRequest bulkRequest = new ElasticsearchBulkRequest();

        // Add some index op
        for (int i = 0; i < nbItems; i++) {
            bulkRequest.add(new ElasticsearchIndexOperation(
                    getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS,
                    "" + i,
                    null,
                    "{\"foo\":{\"bar\":\"bar\"},\"number\": " + i + "}"));
        }

        ElasticsearchEngine engine = new ElasticsearchEngine(esClient);
        ElasticsearchBulkResponse bulkResponse = engine.bulk(bulkRequest);
        Assertions.assertThat(bulkResponse.hasFailures()).isFalse();
        Assertions.assertThat(bulkResponse.getItems()).isNotEmpty();

        // Wait until we have the expected number of documents indexed
        countTestHelper(new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS), nbItems);
    }

    @Test
    void bulk_index_and_delete() throws Exception {
        esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        long nbItems = RandomizedTest.randomLongInRange(randomizedRandomForTests, 5, 20);
        long nbItemsToDelete = RandomizedTest.randomLongInRange(randomizedRandomForTests, 1, nbItems);

        ElasticsearchBulkRequest bulkRequest = new ElasticsearchBulkRequest();

        // Add some index op
        for (int i = 0; i < nbItems; i++) {
            bulkRequest.add(new ElasticsearchIndexOperation(
                    getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS,
                    "" + i,
                    null,
                    "{\"foo\":{\"bar\":\"bar\"},\"number\": " + i + "}"));
        }
        // Add some delete op
        for (int i = 0; i < nbItemsToDelete; i++) {
            bulkRequest.add(
                    new ElasticsearchDeleteOperation(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "" + i));
        }

        ElasticsearchEngine engine = new ElasticsearchEngine(esClient);
        ElasticsearchBulkResponse bulkResponse = engine.bulk(bulkRequest);
        Assertions.assertThat(bulkResponse.hasFailures()).isFalse();
        Assertions.assertThat(bulkResponse.getItems()).isNotEmpty();

        // Wait until we have the expected number of documents indexed
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                nbItems - nbItemsToDelete);
    }

    @Test
    void bulk_index_with_multiline_json() throws Exception {
        esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        long nbItems = RandomizedTest.randomLongInRange(randomizedRandomForTests, 5, 20);

        ElasticsearchBulkRequest bulkRequest = new ElasticsearchBulkRequest();

        // Add some index op with multiline JSON
        for (int i = 0; i < nbItems; i++) {
            bulkRequest.add(new ElasticsearchIndexOperation(
                    getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "" + i, null, """
                            {
                              "foo" : {
                                "bar" : "baz"
                              }
                            }"""));
        }

        ElasticsearchEngine engine = new ElasticsearchEngine(esClient);
        ElasticsearchBulkResponse bulkResponse = engine.bulk(bulkRequest);
        Assertions.assertThat(bulkResponse.hasFailures()).isFalse();
        Assertions.assertThat(bulkResponse.getItems()).isNotEmpty();

        // Wait until we have the expected number of documents indexed
        countTestHelper(new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS), nbItems);
    }

    @Test
    void bulk_index_with_errors() throws Exception {
        esClient.deleteIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        String indexSettings = """
                {
                  "mappings": {
                    "properties": {
                      "foo": {
                        "properties": {
                          "number": {
                            "type": "long"
                          }
                        }
                      }
                    }
                  }
                }""";

        createIndex(indexSettings);

        long nbItems = RandomizedTest.randomLongInRange(randomizedRandomForTests, 6, 20);

        ElasticsearchBulkRequest bulkRequest = new ElasticsearchBulkRequest();

        // Add some index op
        // Every 5 ops, we had a failing document
        long nbErrors = 0;
        for (int i = 0; i < nbItems; i++) {
            if (i > 0 && i % 5 == 0) {
                bulkRequest.add(new ElasticsearchIndexOperation(
                        getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS,
                        "" + i,
                        null,
                        "{\"foo\":{\"bar\":\"bar\",\"number\":\"bar\"}}"));
                nbErrors++;
            } else {
                bulkRequest.add(new ElasticsearchIndexOperation(
                        getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS,
                        "" + i,
                        null,
                        "{\"foo\":{\"bar\":\"bar\",\"number\": " + i + "}}"));
            }
        }
        logger.info("🎯 We index {} items: {} good ✅ and {} bad ❌", nbItems, nbItems - nbErrors, nbErrors);

        ElasticsearchEngine engine = new ElasticsearchEngine(esClient);
        ElasticsearchBulkResponse bulkResponse = engine.bulk(bulkRequest);
        Assertions.assertThat(bulkResponse.hasFailures())
                .as("We should see errors in the bulk response")
                .isTrue();
        Assertions.assertThat(bulkResponse.getItems()).isNotEmpty();
        long errors = bulkResponse.getItems().stream()
                .filter(FsCrawlerBulkResponse.BulkItemResponse::isFailed)
                .count();
        Assertions.assertThat(errors).isEqualTo(nbErrors);

        // Wait until we have the expected number of documents indexed
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                nbItems - nbErrors);
    }

    @Test
    void bulk_create_skips_existing_document() throws Exception {
        String index = getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS;
        esClient.deleteIndex(index);

        String id = "shared-id";
        ElasticsearchBulkRequest firstBulk = new ElasticsearchBulkRequest();
        firstBulk.add(new ElasticsearchCreateOperation(index, id, null, "{\"path\":\"first\",\"content\":\"same\"}"));

        ElasticsearchEngine engine = new ElasticsearchEngine(esClient);
        ElasticsearchBulkResponse firstResponse = engine.bulk(firstBulk);
        Assertions.assertThat(firstResponse.hasFailures()).isFalse();

        countTestHelper(new ESSearchRequest().withIndex(index), 1L);

        ElasticsearchBulkRequest secondBulk = new ElasticsearchBulkRequest();
        secondBulk.add(new ElasticsearchCreateOperation(index, id, null, "{\"path\":\"second\",\"content\":\"same\"}"));

        ElasticsearchBulkResponse secondResponse = engine.bulk(secondBulk);
        Assertions.assertThat(secondResponse.hasFailures())
                .as("create conflict for an existing _id must be treated as non-fatal")
                .isFalse();
        Assertions.assertThat(secondResponse.getItems()).hasSize(1);
        Assertions.assertThat(secondResponse.getItems().get(0).isFailed()).isFalse();

        countTestHelper(new ESSearchRequest().withIndex(index), 1L);
        ESSearchHit hit = esClient.get(index, id);
        Assertions.assertThat(hit.getVersion()).isEqualTo(1L);
        Assertions.assertThat(hit.getSource()).contains("\"path\":\"first\"");
    }

    @Test
    void deleteSingle() throws Exception {
        esClient.indexSingle(
                getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "1", "{ \"foo\": { \"bar\": \"bar\" } }", null);
        esClient.indexSingle(
                getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "2", "{ \"foo\": { \"bar\": \"baz\" } }", null);
        esClient.indexSingle(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "3", "{ \"number\": 1 }", null);
        esClient.indexSingle(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "4", "{ \"number\": 2 }", null);

        ESSearchResponse response = countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS), 4L);
        Assertions.assertThat(response.getTotalHits()).isEqualTo(4L);

        esClient.deleteSingle(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "1");

        response = countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS), 3L);
        Assertions.assertThat(response.getTotalHits()).isEqualTo(3L);

        try {
            esClient.deleteSingle(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "99999");
            Assertions.fail("We should have raised an " + ElasticsearchClientException.class.getSimpleName());
        } catch (ElasticsearchClientException e) {
            Assertions.assertThat(e.getMessage())
                    .isEqualTo(
                            "Document " + getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS + "/99999 does not exist");
        }

        response = countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS), 3L);
        Assertions.assertThat(response.getTotalHits()).isEqualTo(3L);
    }

    @Test
    void exists() throws ElasticsearchClientException {
        esClient.indexSingle(
                getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "1", "{ \"foo\": { \"bar\": \"bar\" } }", null);
        esClient.refresh(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS);
        Assertions.assertThat(esClient.exists(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "1"))
                .isTrue();
        Assertions.assertThat(esClient.exists(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS, "999"))
                .isFalse();
    }

    @Test
    void withOnlyOneRunningNode() throws ElasticsearchClientException, IOException {
        // Build a client with a non-running node
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.getElasticsearch().setUrls(List.of("http://127.0.0.1:9206", testClusterUrl));
        fsSettings.getElasticsearch().setApiKey(testApiKey);
        fsSettings.getElasticsearch().setSslVerification(false);
        try (IElasticsearchClient localClient = new ElasticsearchClient(fsSettings)) {
            Assertions.assertThatNoException().isThrownBy(localClient::start);
            Assertions.assertThat(localClient.isExistingIndex("foo")).isFalse();
            Assertions.assertThat(localClient.isExistingIndex("bar")).isFalse();
            Assertions.assertThat(localClient.isExistingIndex("baz")).isFalse();
        }
    }

    @Test
    void withTwoRunningNodes() throws ElasticsearchClientException, IOException {
        // Build a client with 2 running nodes (well, the same one is used twice) and one non-running node
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings
                .getElasticsearch()
                .setUrls(List.of(testClusterUrl, testClusterUrl, "http://127.0.0.1:9206", testClusterUrl));
        fsSettings.getElasticsearch().setApiKey(testApiKey);
        fsSettings.getElasticsearch().setSslVerification(false);
        try (IElasticsearchClient localClient = new ElasticsearchClient(fsSettings)) {
            localClient.start();

            if (localClient.getMajorVersion() < 8) {
                // We are missing one call when comparing with an ES 8.x cluster
                localClient.isExistingIndex("foo");
            }

            Assertions.assertThat(localClient.getAvailableNodes()).hasSize(4);
            localClient.isExistingIndex("foo");
            Assertions.assertThat(localClient.getAvailableNodes()).hasSize(3);

            for (int i = 0; i < ElasticsearchClient.CHECK_NODES_EVERY - 4; i++) {
                localClient.isExistingIndex("foo");
                Assertions.assertThat(localClient.getAvailableNodes())
                        .as("Run " + i)
                        .hasSize(3);
            }

            for (int i = 0; i < 10; i++) {
                localClient.isExistingIndex("foo");
                Assertions.assertThat(localClient.getAvailableNodes()).hasSize(4);
                localClient.isExistingIndex("foo");
                Assertions.assertThat(localClient.getAvailableNodes())
                        .as("Run " + i)
                        .hasSize(4);
                localClient.isExistingIndex("foo");
                Assertions.assertThat(localClient.getAvailableNodes())
                        .as("Run " + i)
                        .hasSize(3);
                for (int j = 0; j < ElasticsearchClient.CHECK_NODES_EVERY - 4; j++) {
                    localClient.isExistingIndex("foo");
                    Assertions.assertThat(localClient.getAvailableNodes())
                            .as("Run " + i + "-" + j)
                            .hasSize(3);
                }
            }
        }
    }

    @Test
    void withNonRunningNodes() throws IOException {
        // Build a client with a non-running node
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.getElasticsearch().setUrls(List.of("http://127.0.0.1:9206", "http://127.0.0.1:9207"));
        fsSettings.getElasticsearch().setApiKey(testApiKey);
        fsSettings.getElasticsearch().setSslVerification(false);

        try (IElasticsearchClient localClient = new ElasticsearchClient(fsSettings)) {
            Assertions.assertThatExceptionOfType(ElasticsearchClientException.class)
                    .isThrownBy(localClient::start)
                    .withMessageContaining("All nodes are failing");
        }
    }

    @Test
    void withNonRunningNode() throws IOException {
        // Build a client with a non-running node
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.getElasticsearch().setUrls(List.of("http://127.0.0.1:9206"));
        fsSettings.getElasticsearch().setApiKey(testApiKey);
        fsSettings.getElasticsearch().setSslVerification(false);

        try (IElasticsearchClient localClient = new ElasticsearchClient(fsSettings)) {
            Assertions.assertThatExceptionOfType(ElasticsearchClientException.class)
                    .isThrownBy(localClient::start)
                    .withMessageContaining("Can not execute GET")
                    .havingCause()
                    .withCauseInstanceOf(ConnectException.class)
                    .withMessageContaining("Connection refused");
        }
    }

    @Test
    void securedClusterWithBadCredentials() throws IOException, ElasticsearchClientException {
        // Build a client with a null password
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.getElasticsearch().setUrls(List.of(testClusterUrl));
        fsSettings.getElasticsearch().setSslVerification(false);

        try (IElasticsearchClient localClient = new ElasticsearchClient(fsSettings)) {
            localClient.start();
            Assertions.fail("We should have raised a " + ElasticsearchClientException.class.getSimpleName());
        } catch (NotAuthorizedException ex) {
            Assertions.assertThat(ex.getMessage()).contains("HTTP 401 Unauthorized");
        }
    }

    @Test
    void createApiKey() {
        // This is not a critical one as this code is only used in tests
        try {
            String key = esClient.generateApiKey("fscrawler-es-client-test");
            Assertions.assertThat(key).isNotNull();
        } catch (Exception e) {
            // creating derived api keys requires an explicit role descriptor that is empty (has no privileges)
            logger.warn(
                    "Can not create an API Key. "
                            + "This is not a critical one as this code is only used in tests. So we skip it.",
                    e);
        }
    }

    @Test
    @DisabledIfNoDocker
    void withHttpService() throws IOException, ElasticsearchClientException {
        logger.debug("Starting Nginx from {}", rootTmpDir);

        // First we call Elasticsearch client
        Assertions.assertThat(esClient.getVersion()).isNotEmpty();

        Path nginxRoot = rootTmpDir.resolve("nginx-root");
        Files.createDirectories(nginxRoot);
        Files.writeString(nginxRoot.resolve("index.html"), "<html><body>Hello World!</body></html>");

        try (NginxContainer container = new NginxContainer("nginx")) {
            container.waitingFor(new HttpWaitStrategy());
            container.start();
            container.copyFileToContainer(MountableFile.forHostPath(nginxRoot), "/usr/share/nginx/html");
            URL url = container.getBaseUrl("http", 80);
            logger.debug("Nginx started on {}.", url);

            InputStream inputStream = url.openStream();
            String text = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
            Assertions.assertThat(text).contains("Hello World!");
        }

        // Then we call Elasticsearch client again
        Assertions.assertThat(esClient.getVersion()).isNotEmpty();
    }

    @Test
    void license() throws ElasticsearchClientException {
        String license = esClient.getLicense();
        Assertions.assertThat(license).isNotEmpty();
    }

    @Test
    void componentTemplate() throws ElasticsearchClientException {
        String crawlerName = getCrawlerName();

        // Clean up any existing template from previous test runs
        removeComponentTemplates(crawlerName);

        // Check it does not exist
        Assertions.assertThat(esClient.isExistingComponentTemplate(crawlerName)).isFalse();

        // Create a simple component template
        String componentTemplate = """
                {
                  "template": {
                    "mappings": {
                      "properties": {
                        "foo": { "type": "keyword" }
                      }
                    }
                  }
                }""";
        esClient.pushComponentTemplate(crawlerName, componentTemplate);

        Assertions.assertThat(esClient.isExistingComponentTemplate(crawlerName)).isTrue();
        Assertions.assertThat(esClient.isExistingComponentTemplate(crawlerName + "_foo"))
                .isFalse();
    }

    @Nightly
    @VerySlow
    @Test
    void indexFsCrawlerDocuments() throws Exception {
        String docIndex = getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS;

        // Create a temporary client with the correct index name to push templates
        // (createIndexAndComponentTemplates() needs the index configured to generate the right template names)
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.setName(getCrawlerName());
        fsSettings.getElasticsearch().setIndex(docIndex);
        fsSettings.getElasticsearch().setUrls(List.of(testClusterUrl));
        fsSettings.getElasticsearch().setSslVerification(TEST_CHECK_CERTIFICATE);
        fsSettings.getElasticsearch().setCaCertificate(testCaCertificate);
        fsSettings.getElasticsearch().setApiKey(testApiKey);
        try (ElasticsearchClient tempClient = new ElasticsearchClient(fsSettings)) {
            tempClient.start();
            tempClient.createIndexAndComponentTemplates();
        }

        // We create a document
        esClient.index(docIndex, "BackToTheFuture", new Doc("Marty! Let's go back to the future!"), null);
        esClient.index(
                docIndex,
                "StarWars",
                new Doc("Luke. Obiwan never told you what happened to your father. I'm your father!"),
                null);
        esClient.index(
                docIndex,
                "TheLordOfTheRings",
                new Doc(
                        "You cannot pass! I am a servant of the Secret Fire, wielder of the Flame of Anor. The dark fire will not avail you, Flame of Udun! Go back to the shadow. You shall not pass!"),
                null);

        // We flush the bulk request
        esClient.flush();

        // Wait until we have the expected number of documents indexed
        countTestHelper(new ESSearchRequest().withIndex(docIndex), 3L);

        // We can run some queries to check that semantic search actually works as expected
        Assertions.assertThat(esClient.search(new ESSearchRequest()
                                .withIndex(docIndex)
                                .withESQuery(new ESMatchQuery("content", "father")))
                        .getHits()
                        .get(0)
                        .getId())
                .isEqualTo("StarWars");
        Assertions.assertThat(esClient.search(new ESSearchRequest()
                                .withIndex(docIndex)
                                .withESQuery(new ESMatchQuery("content", "future")))
                        .getHits()
                        .get(0)
                        .getId())
                .isEqualTo("BackToTheFuture");
        Assertions.assertThat(esClient.search(new ESSearchRequest()
                                .withIndex(docIndex)
                                .withESQuery(new ESMatchQuery("content", "Flame")))
                        .getHits()
                        .get(0)
                        .getId())
                .isEqualTo("TheLordOfTheRings");

        // We can only execute this test when semantic search is available
        if (esClient.isSemanticSupported()) {
            // We can run some queries to check that semantic search actually works as expected
            Assertions.assertThat(esClient.search(new ESSearchRequest()
                                    .withIndex(docIndex)
                                    .withESQuery(new ESSemanticQuery("content_semantic", "a movie from Georges Lucas")))
                            .getHits()
                            .get(0)
                            .getId())
                    .isEqualTo("StarWars");
            Assertions.assertThat(esClient.search(new ESSearchRequest()
                                    .withIndex(docIndex)
                                    .withESQuery(
                                            new ESSemanticQuery("content_semantic", "a movie with a delorean car")))
                            .getHits()
                            .get(0)
                            .getId())
                    .isEqualTo("BackToTheFuture");
            Assertions.assertThat(esClient.search(new ESSearchRequest()
                                    .withIndex(docIndex)
                                    .withESQuery(new ESSemanticQuery("content_semantic", "Frodo and Gollum")))
                            .getHits()
                            .get(0)
                            .getId())
                    .isEqualTo("TheLordOfTheRings");
        }
    }

    protected static void removeComponentTemplates(String componentTemplateName) {
        logger.trace("Removing component templates for [{}]", componentTemplateName);
        try {
            esClient.performLowLevelRequest("DELETE", "/_component_template/" + componentTemplateName, null);
        } catch (ElasticsearchClientException | NotFoundException e) {
            // We ignore the error
        } catch (BadRequestException e) {
            // We ignore the error
            logger.warn(
                    "Failed to remove component templates. Got a [{}] when calling [DELETE /_component_template/{}]",
                    e.getMessage(),
                    componentTemplateName);
        }
    }

    protected static void removeIndexTemplates(String indexTemplateName) {
        logger.trace("Removing index templates for [{}]", indexTemplateName);
        try {
            esClient.performLowLevelRequest("DELETE", "/_index_template/" + indexTemplateName, null);
        } catch (ElasticsearchClientException | NotFoundException e) {
            // We ignore the error
        } catch (BadRequestException e) {
            // We ignore the error
            logger.warn(
                    "Failed to remove index templates. Got a [{}] when calling [DELETE /_index_template/{}]",
                    e.getMessage(),
                    indexTemplateName);
        }
    }

    /**
     * Check that we have the expected number of docs or at least one if expected is null
     *
     * @param request Elasticsearch request to run.
     * @param expected expected number of docs. Null if at least 1.
     * @return the search response if further tests are needed
     * @throws Exception in case of error
     */
    private static ESSearchResponse countTestHelper(final ESSearchRequest request, final Long expected)
            throws Exception {
        final ESSearchResponse[] response = new ESSearchResponse[1];

        // Wait for the index to be healthy as we might have a race condition
        esClient.waitForHealthyIndex(request.getIndex());

        // We wait before considering a failing test
        logger.info(
                "⏳ Waiting up to {} for {} documents in {}",
                maxWaitForSearch,
                expected == null ? "some" : expected,
                request.getIndex());
        AtomicReference<Exception> errorWhileWaiting = new AtomicReference<>();
        AtomicReference<Long> lastHitCount = new AtomicReference<>();

        try {
            Awaitility.await()
                    .atMost(maxWaitForSearch)
                    .pollInterval(
                            ExponentialBackoffPollInterval.exponential(Duration.ofMillis(500), Duration.ofSeconds(5)))
                    .until(() -> {
                        long totalHits;

                        // Let's search for entries
                        try {
                            // Make sure we refresh indexed docs before counting
                            esClient.refresh(request.getIndex());
                            response[0] = esClient.search(request);
                            errorWhileWaiting.set(null);
                        } catch (RuntimeException e) {
                            logger.warn("error caught", e);
                            errorWhileWaiting.set(e);
                            return false;
                        } catch (ElasticsearchIndexNotFoundException e) {
                            logger.debug("index not ready yet", e);
                            errorWhileWaiting.set(e);
                            return false;
                        } catch (ElasticsearchClientException e) {
                            logger.debug("error caught", e);
                            errorWhileWaiting.set(e);
                            return false;
                        }
                        totalHits = response[0].getTotalHits();
                        lastHitCount.set(totalHits);

                        logger.debug("got so far [{}] hits on expected [{}]", totalHits, expected);

                        if (expected == null) {
                            return totalHits >= 1;
                        }
                        return totalHits == expected;
                    });
        } catch (ConditionTimeoutException e) {
            Long lastHits = lastHitCount.get();
            logger.warn(
                    "Timed out waiting for {} documents in {} after {}. Last observed hit count: {}{}",
                    expected == null ? "some" : expected,
                    request.getIndex(),
                    FsCrawlerUtil.durationToString(maxWaitForSearch),
                    lastHits == null ? "unknown (search never succeeded)" : lastHits,
                    errorWhileWaiting.get() != null
                            ? "; last error: " + errorWhileWaiting.get().getMessage()
                            : "");
            // If we caught an exception during waiting, throw it instead of the timeout
            if (errorWhileWaiting.get() != null) {
                throw errorWhileWaiting.get();
            }
            throw e;
        }

        long hits = response[0].getTotalHits();
        if (expected == null) {
            Assertions.assertThat(hits)
                    .as("checking if any document in %s", request.getIndex())
                    .isGreaterThan(0);
        } else {
            Assertions.assertThat(hits)
                    .as("checking documents in %s", request.getIndex())
                    .isEqualTo(expected);
        }

        return response[0];
    }

    /** Create an index (for tests only) */
    private void createIndex() throws ElasticsearchClientException {
        createIndex(null);
    }

    /**
     * Create an index (for tests only)
     *
     * @param indexSettings index settings if any
     */
    private void createIndex(String indexSettings) throws ElasticsearchClientException {
        String realIndexSettings = indexSettings;
        String index = getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS;
        logger.debug("create index [{}]", index);
        if (indexSettings == null) {
            // We need to pass an empty body because PUT requires a body
            realIndexSettings = "{}";
        }
        logger.trace("index settings: [{}]", realIndexSettings);
        try {
            esClient.httpPut(index, realIndexSettings);
            esClient.waitForHealthyIndex(index);
        } catch (WebApplicationException e) {
            if (e.getResponse().getStatusInfo().getFamily() == Response.Status.Family.CLIENT_ERROR) {
                logger.debug("Response for create index [{}]: {}", index, e.getMessage());
                DocumentContext document =
                        JsonUtil.parseJsonAsDocumentContext(e.getResponse().readEntity(String.class));
                String errorType = document.read("$.error.type");
                if (!errorType.contains("resource_already_exists_exception")) {
                    throw new ElasticsearchClientException(
                            "error while creating index " + index + ": " + document.read("$"));
                }
            } else {
                throw new ElasticsearchClientException("Error while creating index " + index, e);
            }
        }
    }
}
