/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.client;

import fr.pilato.elasticsearch.crawler.fs.settings.BulkOperation;

/** Bulk write operation that carries a document body ({@code index} or {@code create}). */
public abstract class ElasticsearchInsertOperation extends ElasticsearchOperation {

    private final String pipeline;
    private final String json;

    protected ElasticsearchInsertOperation(
            BulkOperation operation, String index, String id, String pipeline, String json) {
        super(operation, index, id);
        this.pipeline = pipeline;
        this.json = json;
    }

    public String getPipeline() {
        return pipeline;
    }

    public String getJson() {
        return json;
    }
}
