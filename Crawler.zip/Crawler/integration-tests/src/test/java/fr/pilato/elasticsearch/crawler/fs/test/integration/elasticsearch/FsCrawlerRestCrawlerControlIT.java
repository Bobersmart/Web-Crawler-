/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.test.integration.elasticsearch;

import com.carrotsearch.randomizedtesting.jupiter.RandomizedTest;
import fr.pilato.elasticsearch.crawler.fs.FsCrawlerImpl;
import fr.pilato.elasticsearch.crawler.fs.beans.CrawlerState;
import fr.pilato.elasticsearch.crawler.fs.beans.FsCrawlerCheckpoint;
import fr.pilato.elasticsearch.crawler.fs.client.ESSearchRequest;
import fr.pilato.elasticsearch.crawler.fs.client.ESSearchResponse;
import fr.pilato.elasticsearch.crawler.fs.client.ElasticsearchClientException;
import fr.pilato.elasticsearch.crawler.fs.framework.FsCrawlerUtil;
import fr.pilato.elasticsearch.crawler.fs.framework.TimeValue;
import fr.pilato.elasticsearch.crawler.fs.rest.CrawlerStatusResponse;
import fr.pilato.elasticsearch.crawler.fs.rest.RestJsonProvider;
import fr.pilato.elasticsearch.crawler.fs.rest.RestServer;
import fr.pilato.elasticsearch.crawler.fs.rest.SimpleResponse;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.test.framework.VerySlow;
import fr.pilato.elasticsearch.crawler.fs.test.integration.AbstractFsCrawlerITCase;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.net.ServerSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tools.jackson.jakarta.rs.json.JacksonJsonProvider;

/**
 * Integration tests for the REST API crawler control endpoints (pause, resume, checkpoint). These tests use a real
 * crawler alongside the REST server to test the control functionality.
 */
class FsCrawlerRestCrawlerControlIT extends AbstractFsCrawlerITCase {
    private static final Logger logger = LogManager.getLogger();

    private RestServer restServer;
    private Client httpClient;
    private WebTarget target;
    private int restPort;

    @BeforeEach
    void startRestServer() throws Exception {
        // Find an available port
        try (ServerSocket serverSocket = new ServerSocket(0)) {
            restPort = serverSocket.getLocalPort();
        }
        logger.info("🛠️ Using REST port [{}] for test", restPort);

        // Create HTTP client
        httpClient = ClientBuilder.newBuilder()
                .register(RestJsonProvider.class)
                .register(JacksonJsonProvider.class)
                .build();
        target = httpClient.target("http://127.0.0.1:" + restPort + "/fscrawler");
    }

    @AfterEach
    void stopRestServer() {
        if (restServer != null) {
            restServer.close();
            restServer = null;
        }
        if (httpClient != null) {
            httpClient.close();
            httpClient = null;
        }
    }

    /**
     * Test scenario 1: Pause the crawler, verify no documents indexed during pause, then resume and verify indexing
     * completes.
     *
     * <p>Note: We create a deep directory structure to slow down the crawler enough to be able to pause it mid-scan. We
     * verify that NO NEW documents are indexed while paused (some might have been indexed before the pause took
     * effect).
     */
    @Test
    @VerySlow
    void test_pause_resume_indexing() throws Exception {
        // Create a deep directory structure with many files to slow down scanning
        long nbFolders = RandomizedTest.randomLongInRange(randomizedRandomForTests, 5, 20);
        long nbFiles = RandomizedTest.randomLongInRange(randomizedRandomForTests, 100, 1000);

        Path testDir = currentTestResourceDir;
        for (long i = 0; i < nbFolders; i++) {
            Path subDir = testDir.resolve("subdir_" + i);
            Files.createDirectories(subDir);
            for (long j = 0; j < nbFiles; j++) {
                Files.writeString(subDir.resolve("file_" + j + ".txt"), "Content of file " + i + "_" + j);
            }
        }

        long expectedDocs = 1L + nbFolders * nbFiles; // x subdirs * y files + 1 from _common
        logger.info("📂 Created {} documents within {} folders", expectedDocs, nbFolders);

        // Create settings with a reasonable update rate
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueMinutes(5)); // Long update rate to avoid second scan

        // Start crawler with REST
        try (FsCrawlerImpl fsCrawler = startCrawlerWithRest(fsSettings)) {
            // Wait until enough documents are indexed (bulk flushes can skip exact counts).
            final long minDocsBeforePause = 10L;
            ESSearchResponse responseAfterStart =
                    awaitMinDocumentCount(fsSettings.getElasticsearch().getIndex(), minDocsBeforePause);

            logger.info(
                    "⏸️ Pausing crawler. We have {} documents indexed so far on {} expected...",
                    responseAfterStart.getTotalHits(),
                    expectedDocs);
            SimpleResponse pauseResponse = restPauseCrawler();
            Assertions.assertThat(pauseResponse.isOk()).isTrue();
            Assertions.assertThat(pauseResponse.getMessage()).contains("paused");

            // Verify status shows PAUSED
            CrawlerStatusResponse status = restGetCrawlerStatus();
            Assertions.assertThat(status.getState()).isEqualTo(CrawlerState.PAUSED);

            // Files already past the pause gate and bulk requests in flight may still be indexed briefly.
            long docsBeforePause =
                    awaitStableDocumentCount(fsSettings.getElasticsearch().getIndex());
            logger.info("📍 Documents indexed before pause (stable): {}", docsBeforePause);

            FsCrawlerUtil.waitFor(Duration.ofSeconds(2));

            refresh(fsSettings.getElasticsearch().getIndex());
            ESSearchResponse searchAfterPause = client.search(new ESSearchRequest()
                    .withIndex(fsSettings.getElasticsearch().getIndex()));
            long docsAfterPause = searchAfterPause.getTotalHits();
            logger.info("📍 Documents indexed after pause: {}", docsAfterPause);

            // Verify no new documents were indexed during the pause period
            Assertions.assertThat(docsAfterPause)
                    .as("No new documents should be indexed while paused")
                    .isEqualTo(docsBeforePause);

            // Resume the crawler
            logger.info("⏯️ Resuming crawler...");
            SimpleResponse resumeResponse = restResumeCrawler();
            Assertions.assertThat(resumeResponse.isOk()).isTrue();
            Assertions.assertThat(resumeResponse.getMessage()).contains("resumed");

            // Count expected files
            countTestHelper(
                    new ESSearchRequest()
                            .withIndex(fsSettings.getElasticsearch().getIndex()),
                    expectedDocs,
                    testDir);
        }
    }

    /** Test scenario 2: Delete checkpoint and verify documents are re-indexed. */
    @Test
    void test_delete_checkpoint_reindex() throws Exception {
        // Create a small set of test files
        long nbFiles = RandomizedTest.randomLongInRange(randomizedRandomForTests, 5, 10);
        for (int i = 0; i < nbFiles; i++) {
            Files.writeString(currentTestResourceDir.resolve("doc_" + i + ".txt"), "Document content " + i);
        }

        // Create settings
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueMinutes(10)); // Long rate to control scans

        // Start crawler with REST
        try (FsCrawlerImpl fsCrawler = startCrawlerWithRest(fsSettings)) {
            // Wait for initial indexing to complete
            long expectedDocs = Files.list(currentTestResourceDir)
                    .filter(Files::isRegularFile)
                    .count();
            logger.info("⏳ Waiting for {} documents to be indexed...", expectedDocs);
            countTestHelper(
                    new ESSearchRequest()
                            .withIndex(fsSettings.getElasticsearch().getIndex()),
                    expectedDocs,
                    currentTestResourceDir);

            // Wait for the scan to complete (state should be COMPLETED)
            Awaitility.await()
                    .atMost(Duration.ofSeconds(30))
                    .pollInterval(Duration.ofMillis(500))
                    .until(() -> fsCrawler.getFsParser().getState() == CrawlerState.COMPLETED);

            // Pause the crawler before deleting checkpoint
            logger.info("⏸️ Pausing crawler before clearing checkpoint...");
            SimpleResponse pauseResponse = restPauseCrawler();
            Assertions.assertThat(pauseResponse.isOk()).isTrue();
            // Verify crawler is paused
            Assertions.assertThat(fsCrawler.getFsParser().getState()).isEqualTo(CrawlerState.PAUSED);

            // Delete the checkpoint
            logger.info("⌫ Deleting checkpoint...");
            SimpleResponse deleteResponse = restDeleteCheckpoint();
            Assertions.assertThat(deleteResponse.isOk()).isTrue();
            Assertions.assertThat(deleteResponse.getMessage()).contains("cleared");
            // Verify crawler is still paused
            Assertions.assertThat(fsCrawler.getFsParser().getState()).isEqualTo(CrawlerState.PAUSED);

            // Clear the Elasticsearch index to verify re-indexing
            logger.info("⌫ Clearing Elasticsearch index to verify re-indexing...");
            client.deleteIndex(fsSettings.getElasticsearch().getIndex());

            // Record the current run number so we can deterministically detect the resumed run.
            // resume() dispatches a new run asynchronously on the crawler thread; asserting the transient
            // RUNNING state synchronously right after resume() is racy: the resumed run may not have started
            // yet (state still COMPLETED), or may already have finished/failed (state COMPLETED or PAUSED).
            // The monotonic run counter is a race-free signal that a new run was actually triggered.
            int runNumberBeforeResume = fsCrawler.getFsParser().getRunNumber();

            // Resume the crawler - it should re-index everything
            logger.info("⏯️ Resuming crawler after checkpoint deletion...");
            SimpleResponse resumeResponse = restResumeCrawler();
            Assertions.assertThat(resumeResponse.isOk()).isTrue();

            // Verify resume triggered a new run. The run number is incremented at the start of every run
            // (before any work), so this holds regardless of how fast the resumed run scans.
            Awaitility.await()
                    .atMost(Duration.ofSeconds(10))
                    .pollInterval(Duration.ofMillis(100))
                    .until(() -> fsCrawler.getFsParser().getRunNumber() > runNumberBeforeResume);

            // Wait for documents to be re-indexed
            logger.info("⏳ Waiting for {} documents to be re-indexed...", expectedDocs);
            countTestHelper(
                    new ESSearchRequest()
                            .withIndex(fsSettings.getElasticsearch().getIndex()),
                    expectedDocs,
                    currentTestResourceDir);

            // Wait until the crawler is marked as COMPLETED again
            Awaitility.await()
                    .atMost(Duration.ofSeconds(30))
                    .pollInterval(Duration.ofMillis(500))
                    .until(() -> fsCrawler.getFsParser().getState() == CrawlerState.COMPLETED);
        }
    }

    /**
     * Test scenario 3: Verify crawler status endpoint returns correct information including scanEndTime and nextCheck
     * after a completed scan.
     */
    @Test
    void test_status_after_completed_scan() throws Exception {
        // Create test files
        long nbFiles = RandomizedTest.randomLongInRange(randomizedRandomForTests, 3, 10);
        for (int i = 0; i < nbFiles; i++) {
            Files.writeString(currentTestResourceDir.resolve("status_test_" + i + ".txt"), "Status test " + i);
        }

        // Create settings with short update rate
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueSeconds(30));

        // Start crawler with REST
        FsCrawlerImpl fsCrawler = startCrawlerWithRest(fsSettings);

        // Wait for initial indexing
        long expectedDocs =
                Files.list(currentTestResourceDir).filter(Files::isRegularFile).count();
        countTestHelper(
                new ESSearchRequest().withIndex(fsSettings.getElasticsearch().getIndex()),
                expectedDocs,
                currentTestResourceDir);

        // Wait for the scan to be marked as COMPLETED
        Awaitility.await()
                .atMost(Duration.ofSeconds(30))
                .pollInterval(Duration.ofMillis(500))
                .until(() -> fsCrawler.getFsParser().getState() == CrawlerState.COMPLETED);

        // Get status and verify it contains the expected fields
        CrawlerStatusResponse status = restGetCrawlerStatus();
        logger.info(
                "✅ Crawler status: state={}, filesProcessed={}, scanEndTime={}, nextCheck={}",
                status.getState(),
                status.getFilesProcessed(),
                status.getScanEndTime(),
                status.getNextCheck());

        Assertions.assertThat(status.getState()).isEqualTo(CrawlerState.COMPLETED);
        Assertions.assertThat(status.getFilesProcessed()).isEqualTo(expectedDocs);
        Assertions.assertThat(status.getScanEndTime()).isNotNull();
        Assertions.assertThat(status.getNextCheck()).isNotNull().isAfter(status.getScanEndTime());
    }

    @Test
    void test_pause_already_paused() throws Exception {
        // Flat file sets finish in ~100 ms on CI; subdirs keep the first scan observable long enough to pause.
        long nbFolders = RandomizedTest.randomLongInRange(randomizedRandomForTests, 5, 10);
        long nbFilesPerFolder = RandomizedTest.randomLongInRange(randomizedRandomForTests, 30, 50);
        for (long i = 0; i < nbFolders; i++) {
            Path subDir = currentTestResourceDir.resolve("status_paused_" + i);
            Files.createDirectories(subDir);
            for (long j = 0; j < nbFilesPerFolder; j++) {
                Files.writeString(subDir.resolve("file_" + j + ".txt"), "Already Paused test " + i + "_" + j);
            }
        }
        long expectedDocs = 1L + nbFolders * nbFilesPerFolder;

        // Create settings with a reasonable update rate
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueMinutes(5)); // Long update rate to avoid second scan

        // Start crawler with REST
        try (FsCrawlerImpl fsCrawler = startCrawlerWithRest(fsSettings)) {
            // RUNNING is transient; poll frequently and pause on the first observation so we do not miss the window.
            AtomicBoolean pauseRequested = new AtomicBoolean(false);
            AtomicReference<SimpleResponse> pauseResponseRef = new AtomicReference<>();
            Awaitility.await()
                    .atMost(Duration.ofSeconds(60))
                    .pollInterval(Duration.ofMillis(10))
                    .until(() -> {
                        CrawlerState state = fsCrawler.getFsParser().getState();
                        if (state == CrawlerState.RUNNING && pauseRequested.compareAndSet(false, true)) {
                            pauseResponseRef.set(restPauseCrawler());
                        }
                        SimpleResponse pauseResponse = pauseResponseRef.get();
                        if (pauseResponse != null) {
                            return pauseResponse.getMessage().contains("Crawler paused. Checkpoint saved.");
                        }
                        if (fsCrawler.getFsParser().getRunNumber() > 0 && state == CrawlerState.COMPLETED) {
                            throw new AssertionError("First scan completed before REST pause could save a checkpoint");
                        }
                        return false;
                    });

            SimpleResponse pauseResponse = pauseResponseRef.get();
            Assertions.assertThat(pauseResponse.isOk()).isTrue();
            Assertions.assertThat(fsCrawler.getFsParser().getState()).isEqualTo(CrawlerState.PAUSED);

            logger.info("⏸️ Pausing again the crawler.");
            SimpleResponse pauseResponse2 = restPauseCrawler();
            Assertions.assertThat(pauseResponse2.isOk()).isTrue();
            Assertions.assertThat(pauseResponse2.getMessage()).contains("Crawler is already paused.");
            Assertions.assertThat(fsCrawler.getFsParser().getState()).isEqualTo(CrawlerState.PAUSED);

            logger.info("⏯️ Resuming crawler...");
            SimpleResponse resumeResponse = restResumeCrawler();
            Assertions.assertThat(resumeResponse.isOk()).isTrue();
            Assertions.assertThat(resumeResponse.getMessage()).contains("Crawler resumed.");

            // Resume continues the same run (runNumber unchanged); wait for indexing to finish.
            countTestHelper(
                    new ESSearchRequest()
                            .withIndex(fsSettings.getElasticsearch().getIndex()),
                    expectedDocs,
                    currentTestResourceDir);
        }
    }

    @Test
    @VerySlow
    void status_during_scan() throws Exception {
        // Create a deep directory structure with many files to slow down scanning
        long nbFolders = RandomizedTest.randomLongInRange(randomizedRandomForTests, 5, 20);
        long nbFiles = RandomizedTest.randomLongInRange(randomizedRandomForTests, 100, 1000);

        Path testDir = currentTestResourceDir;
        for (long i = 0; i < nbFolders; i++) {
            Path subDir = testDir.resolve("subdir_" + i);
            Files.createDirectories(subDir);
            for (long j = 0; j < nbFiles; j++) {
                Files.writeString(subDir.resolve("file_" + j + ".txt"), "Content of file " + i + "_" + j);
            }
        }

        long expectedDocs = 1L + nbFolders * nbFiles; // x subdirs * y files + 1 from _common
        logger.info("📂 Created {} documents within {} folders", expectedDocs, nbFolders);

        // Create settings with a reasonable update rate
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueMinutes(5)); // Long update rate to avoid second scan

        // Start crawler with REST
        try (FsCrawlerImpl fsCrawler = startCrawlerWithRest(fsSettings)) {
            // Verify status shows RUNNING
            CrawlerStatusResponse status = restGetCrawlerStatus();
            Assertions.assertThat(status.getState()).isEqualTo(CrawlerState.RUNNING);

            final AtomicLong counterFiles = new AtomicLong(status.getFilesProcessed());
            final AtomicInteger counterCompletedDirs = new AtomicInteger(status.getCompletedDirectories());
            Awaitility.await()
                    .pollInterval(Duration.ofSeconds(1))
                    .timeout(Duration.ofMinutes(5))
                    .until(() -> {
                        CrawlerStatusResponse s = restGetCrawlerStatus();
                        logger.info(
                                "📊 Crawler status while scanning: completedDirs={}, filesProcessed={}, pendingDirs={}",
                                s.getCompletedDirectories(),
                                s.getFilesProcessed(),
                                s.getPendingDirectories());
                        FsCrawlerCheckpoint checkpoint = fsCrawler.getFsParser().getCheckpoint();
                        logger.debug("Current dir: {}", checkpoint.getCurrentPath());
                        logger.debug("Remaining dirs: {}", checkpoint.getPendingPaths());
                        logger.trace("Checkpoint: {}", checkpoint);
                        long oldFiles = counterFiles.getAndSet(s.getFilesProcessed());
                        int oldCompletedDirs = counterCompletedDirs.getAndSet(s.getCompletedDirectories());
                        Assertions.assertThat(s.getFilesProcessed()).isGreaterThanOrEqualTo(oldFiles);
                        if (s.getState() == CrawlerState.COMPLETED) {
                            Assertions.assertThat(s.getCompletedDirectories()).isZero();
                            Assertions.assertThat(s.getPendingDirectories()).isZero();
                        } else {
                            Assertions.assertThat(s.getCompletedDirectories()).isGreaterThanOrEqualTo(oldCompletedDirs);
                        }

                        // We wait until the crawler is completed and has no pending directories
                        return s.getState() == CrawlerState.COMPLETED && s.getPendingDirectories() == 0;
                    });

            Assertions.assertThat(fsCrawler.getFsParser().getState()).isEqualTo(CrawlerState.COMPLETED);

            // Count expected files
            countTestHelper(
                    new ESSearchRequest()
                            .withIndex(fsSettings.getElasticsearch().getIndex()),
                    expectedDocs,
                    testDir);
        }
    }

    // Utility methods for REST API calls

    /** Start the crawler with REST server enabled */
    private FsCrawlerImpl startCrawlerWithRest(FsSettings fsSettings) throws Exception {
        // Configure REST
        fsSettings.getRest().setUrl("http://127.0.0.1:" + restPort + "/fscrawler");

        // Create the crawler
        crawler = new FsCrawlerImpl(metadataDir, fsSettings, FsCrawlerImpl.LOOP_INFINITE, true);
        // Create the Rest server
        restServer = new RestServer(
                fsSettings,
                crawler.getManagementService(),
                crawler.getDocumentService(),
                crawler.getPluginsManager(),
                crawler.getFsParser());

        // Start the REST server before the crawler so POST /pause is available as soon as the first run starts.
        restServer.start();

        // Start the crawler
        crawler.start();

        return crawler;
    }

    /** Call POST /_crawler/pause */
    private SimpleResponse restPauseCrawler() {
        try (Response response = target.path("/_crawler/pause")
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.json(""))) {
            return response.readEntity(SimpleResponse.class);
        }
    }

    /** Call POST /_crawler/resume */
    private SimpleResponse restResumeCrawler() {
        try (Response response = target.path("/_crawler/resume")
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.json(""))) {
            return response.readEntity(SimpleResponse.class);
        }
    }

    /** Call GET /_crawler/status */
    private CrawlerStatusResponse restGetCrawlerStatus() {
        return target.path("/_crawler/status")
                .request(MediaType.APPLICATION_JSON)
                .get(CrawlerStatusResponse.class);
    }

    /** Call DELETE /_crawler/checkpoint */
    private SimpleResponse restDeleteCheckpoint() {
        try (Response response = target.path("/_crawler/checkpoint")
                .request(MediaType.APPLICATION_JSON)
                .delete()) {
            return response.readEntity(SimpleResponse.class);
        }
    }

    /**
     * Poll until at least {@code minCount} documents are visible in Elasticsearch. Unlike
     * {@link fr.pilato.elasticsearch.crawler.fs.test.integration.AbstractITCase#countTestHelper}, this tolerates bulk
     * flushes that skip intermediate hit counts.
     */
    private ESSearchResponse awaitMinDocumentCount(String index, long minCount) {
        AtomicReference<ESSearchResponse> responseRef = new AtomicReference<>();
        Awaitility.await()
                .atMost(Duration.ofMinutes(5))
                .pollInterval(Duration.ofMillis(500))
                .until(() -> {
                    try {
                        refresh(index);
                        ESSearchResponse response = client.search(new ESSearchRequest().withIndex(index));
                        responseRef.set(response);
                        return response.getTotalHits() >= minCount;
                    } catch (RuntimeException | ElasticsearchClientException e) {
                        logger.debug("awaitMinDocumentCount: index not ready yet [{}]", e.getMessage());
                        return false;
                    }
                });
        return responseRef.get();
    }

    /**
     * Poll until the document count in Elasticsearch stops increasing. Used after pausing the crawler so in-flight bulk
     * requests and files already past the pause gate are not mistaken for indexing during pause.
     */
    private long awaitStableDocumentCount(String index) {
        AtomicLong lastCount = new AtomicLong(-1);
        AtomicInteger stableSamples = new AtomicInteger(0);
        Awaitility.await()
                .atMost(Duration.ofSeconds(30))
                .pollInterval(Duration.ofMillis(300))
                .until(() -> {
                    try {
                        refresh(index);
                        long hits = client.search(new ESSearchRequest().withIndex(index))
                                .getTotalHits();
                        if (hits == lastCount.get()) {
                            return stableSamples.incrementAndGet() >= 3;
                        }
                        lastCount.set(hits);
                        stableSamples.set(0);
                        return false;
                    } catch (RuntimeException | ElasticsearchClientException e) {
                        logger.debug("awaitStableDocumentCount: index not ready yet [{}]", e.getMessage());
                        return false;
                    }
                });
        return lastCount.get();
    }
}
