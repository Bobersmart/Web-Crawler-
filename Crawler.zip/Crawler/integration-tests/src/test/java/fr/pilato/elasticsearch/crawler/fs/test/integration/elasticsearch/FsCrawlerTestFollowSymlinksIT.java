/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.test.integration.elasticsearch;

import fr.pilato.elasticsearch.crawler.fs.client.ESSearchRequest;
import fr.pilato.elasticsearch.crawler.fs.framework.FsCrawlerUtil;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.test.integration.AbstractFsCrawlerITCase;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.OS;

/** Test with symlinks */
class FsCrawlerTestFollowSymlinksIT extends AbstractFsCrawlerITCase {

    @Test
    @DisabledOnOs(value = OS.WINDOWS, disabledReason = "We cannot create symlink on Windows OS")
    void follow_symlinks_disabled() throws Exception {
        Path source = currentTestResourceDir.resolve("roottxtfile.txt");
        Path link = currentTestResourceDir.resolve("link_roottxtfile.txt");
        Files.createSymbolicLink(link, source);

        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setFollowSymlinks(false);
        crawler = startCrawler(fsSettings);

        // We should have two docs first
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                1L,
                currentTestResourceDir);
    }

    @Test
    @DisabledOnOs(value = OS.WINDOWS, disabledReason = "We cannot create symlink on Windows OS")
    void follow_symlinks_enabled() throws Exception {
        Path source = currentTestResourceDir.resolve("roottxtfile.txt");
        Path link = currentTestResourceDir.resolve("link_roottxtfile.txt");
        Files.createSymbolicLink(link, source);

        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setFollowSymlinks(true);
        crawler = startCrawler(fsSettings);

        // We should have two docs first
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                2L,
                currentTestResourceDir);
    }
}
