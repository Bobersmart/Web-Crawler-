/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.test.integration.elasticsearch;

import fr.pilato.elasticsearch.crawler.fs.beans.FsCrawlerCheckpoint;
import fr.pilato.elasticsearch.crawler.fs.beans.FsCrawlerCheckpointFileHandler;
import fr.pilato.elasticsearch.crawler.fs.client.ESSearchHit;
import fr.pilato.elasticsearch.crawler.fs.client.ESSearchRequest;
import fr.pilato.elasticsearch.crawler.fs.client.ESSearchResponse;
import fr.pilato.elasticsearch.crawler.fs.framework.ExponentialBackoffPollInterval;
import fr.pilato.elasticsearch.crawler.fs.framework.FsCrawlerUtil;
import fr.pilato.elasticsearch.crawler.fs.framework.TimeValue;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.test.integration.AbstractFsCrawlerITCase;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;

/** Test moving/removing/adding files */
class FsCrawlerTestAddNewFilesIT extends AbstractFsCrawlerITCase {
    private static final Logger logger = LogManager.getLogger();

    @Test
    void add_new_files_and_force_rescan() throws Exception {
        FsSettings fsSettings = createTestSettings();
        // We want to wait the default wait time which is 15 minutes.
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueMinutes(15));
        crawler = startCrawler(fsSettings);

        // We should have one doc first
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                1L,
                currentTestResourceDir);

        // We add a file
        logger.info("  ---> Adding file new_roottxtfile.txt");
        Files.write(
                currentTestResourceDir.resolve("new_roottxtfile.txt"),
                "This is a second file".getBytes(StandardCharsets.UTF_8));

        // Forcing a rescan by modifying the next scan date
        logger.info("  ---> changing next check date to now manually");
        waitForFsJobAndSetDate(fsSettings.getName(), Instant.now());

        // We expect to have two files
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                2L,
                currentTestResourceDir);
    }

    @Test
    void add_new_files_and_force_rescan_with_null() throws Exception {
        FsSettings fsSettings = createTestSettings();
        // We want to wait the default wait time which is 15 minutes.
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueMinutes(15));
        crawler = startCrawler(fsSettings);

        // We should have one doc first
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                1L,
                currentTestResourceDir);

        // We add a file
        logger.info("  ---> Adding file new_roottxtfile.txt");
        Files.write(
                currentTestResourceDir.resolve("new_roottxtfile.txt"),
                "This is a second file".getBytes(StandardCharsets.UTF_8));

        // Forcing a rescan by modifying the next scan date
        logger.info("  ---> removing next check date to force a manual rescan");
        waitForFsJobAndSetDate(fsSettings.getName(), null);

        // We expect to have two files
        countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                2L,
                currentTestResourceDir);
    }

    /**
     * Test case for issue #60: <a
     * href="https://github.com/dadoonet/fscrawler/issues/60">https://github.com/dadoonet/fscrawler/issues/60</a> : new
     * files are not added
     */
    @Test
    void add_new_file() throws Exception {
        // We need to wait for 2 seconds before starting the test as the file might have just been created
        // It's due to https://github.com/dadoonet/fscrawler/issues/82 which removes 2 seconds from the last scan date
        FsCrawlerUtil.waitFor(Duration.ofSeconds(2));

        FsSettings fsSettings = createTestSettings();
        // We change the update rate to 5 seconds because the FsParser last scan date is set to 2 seconds less than the
        // current time
        fsSettings.getFs().setUpdateRate(TimeValue.timeValueSeconds(5));
        crawler = startCrawler(fsSettings);

        // We should have one doc first
        ESSearchResponse response = countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                1L,
                currentTestResourceDir);
        checkDocVersions(response, 1L);

        logger.info(" ---> Creating a new file new_roottxtfile.txt");
        Files.write(currentTestResourceDir.resolve("new_roottxtfile.txt"), "This is a second file".getBytes());

        // We expect to have two files
        response = countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                2L,
                currentTestResourceDir);

        // It should be only version <= 2 for both docs
        checkDocVersions(response, 2L);

        logger.info(" ---> Creating a new file new_new_roottxtfile.txt");
        Files.write(currentTestResourceDir.resolve("new_new_roottxtfile.txt"), "This is a third file".getBytes());

        // We expect to have three files
        response = countTestHelper(
                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS),
                3L,
                currentTestResourceDir);

        // It should be only version <= 2 for all docs
        checkDocVersions(response, 2L);
    }

    /**
     * Iterate other response hits and check that _version is at most a given version
     *
     * @param response The search response object
     * @param maxVersion Maximum version number we can have
     */
    private void checkDocVersions(ESSearchResponse response, long maxVersion) {
        // It should be only version <= maxVersion for all docs
        Assertions.assertThat(response.getHits()).isNotEmpty().allSatisfy(hit -> {
            ESSearchHit getHit = client.get(hit.getIndex(), hit.getId());
            Assertions.assertThat(getHit.getVersion()).isLessThanOrEqualTo(maxVersion);
        });
    }

    private void waitForFsJobAndSetDate(String jobName, Instant dateTime) {
        Awaitility.await()
                .pollInterval(ExponentialBackoffPollInterval.exponential(Duration.ofMillis(500), Duration.ofSeconds(5)))
                .atMost(10, TimeUnit.SECONDS)
                .until(() -> {
                    try {
                        FsCrawlerCheckpointFileHandler checkpointHandler =
                                new FsCrawlerCheckpointFileHandler(metadataDir);
                        FsCrawlerCheckpoint checkpoint = checkpointHandler.read(jobName);
                        checkpoint.setNextCheck(dateTime);
                        checkpointHandler.write(jobName, checkpoint);
                        return true;
                    } catch (Exception e) {
                        logger.warn("Checkpoint is not available yet: [{}] : {}", jobName, e.getMessage());
                        logger.debug("Error while reading checkpoint", e);
                        return false;
                    }
                });
    }
}
