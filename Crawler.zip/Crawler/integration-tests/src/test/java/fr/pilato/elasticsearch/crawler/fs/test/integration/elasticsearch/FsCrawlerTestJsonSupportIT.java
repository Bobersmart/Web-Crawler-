/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.test.integration.elasticsearch;

import fr.pilato.elasticsearch.crawler.fs.client.ESMatchQuery;
import fr.pilato.elasticsearch.crawler.fs.client.ESSearchRequest;
import fr.pilato.elasticsearch.crawler.fs.client.ESSearchResponse;
import fr.pilato.elasticsearch.crawler.fs.client.ElasticsearchClientException;
import fr.pilato.elasticsearch.crawler.fs.framework.ExponentialBackoffPollInterval;
import fr.pilato.elasticsearch.crawler.fs.framework.FsCrawlerUtil;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.test.integration.AbstractFsCrawlerITCase;
import java.time.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;

/** Test json support crawler setting */
class FsCrawlerTestJsonSupportIT extends AbstractFsCrawlerITCase {
    private static final Logger logger = LogManager.getLogger();

    /**
     * Test case for issue #5: <a
     * href="https://github.com/dadoonet/fscrawler/issues/5">https://github.com/dadoonet/fscrawler/issues/5</a> :
     * Support JSon documents
     */
    @Test
    void json_support() throws Exception {
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setJsonSupport(true);
        crawler = startCrawler(fsSettings);

        Awaitility.await()
                .atMost(MAX_WAIT_FOR_SEARCH)
                .alias("We should have 2 doc for tweet in text field...")
                .pollInterval(ExponentialBackoffPollInterval.exponential(Duration.ofMillis(500), Duration.ofSeconds(5)))
                .until(() -> {
                    try {
                        ESSearchResponse response = client.search(new ESSearchRequest()
                                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                                .withESQuery(new ESMatchQuery("text", "tweet")));
                        return response.getTotalHits() == 2;
                    } catch (ElasticsearchClientException e) {
                        logger.warn("Caught exception while running the test", e);
                        return false;
                    }
                });
    }

    /**
     * Test case for issue #5: <a
     * href="https://github.com/dadoonet/fscrawler/issues/5">https://github.com/dadoonet/fscrawler/issues/5</a> :
     * Support JSon documents
     */
    @Test
    void json_disabled() throws Exception {
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setJsonSupport(false);
        crawler = startCrawler(fsSettings);

        Awaitility.await()
                .atMost(MAX_WAIT_FOR_SEARCH)
                .alias("We should have 0 doc for tweet in text field...")
                .pollInterval(ExponentialBackoffPollInterval.exponential(Duration.ofMillis(500), Duration.ofSeconds(5)))
                .until(() -> {
                    try {
                        ESSearchResponse response = client.search(new ESSearchRequest()
                                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                                .withESQuery(new ESMatchQuery("text", "tweet")));
                        return response.getTotalHits() == 0;
                    } catch (ElasticsearchClientException e) {
                        logger.warn("Caught exception while running the test", e);
                        return false;
                    }
                });

        Awaitility.await()
                .atMost(MAX_WAIT_FOR_SEARCH)
                .alias("We should have 2 docs for tweet in content field...")
                .pollInterval(ExponentialBackoffPollInterval.exponential(Duration.ofMillis(500), Duration.ofSeconds(5)))
                .until(() -> {
                    try {
                        ESSearchResponse response = client.search(new ESSearchRequest()
                                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                                .withESQuery(new ESMatchQuery("content", "tweet")));
                        return response.getTotalHits() == 2;
                    } catch (ElasticsearchClientException e) {
                        logger.warn("Caught exception while running the test", e);
                        return false;
                    }
                });
    }

    /**
     * Test case for issue #237: <a
     * href="https://github.com/dadoonet/fscrawler/issues/237">https://github.com/dadoonet/fscrawler/issues/237</a>
     * Delete json documents
     */
    @Test
    void add_as_inner_object() throws Exception {
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setJsonSupport(true);
        fsSettings.getFs().setAddAsInnerObject(true);
        crawler = startCrawler(fsSettings);

        Awaitility.await()
                .atMost(MAX_WAIT_FOR_SEARCH)
                .alias("We should have 2 doc for tweet in object.text field...")
                .pollInterval(ExponentialBackoffPollInterval.exponential(Duration.ofMillis(500), Duration.ofSeconds(5)))
                .until(() -> {
                    try {
                        ESSearchResponse response = client.search(new ESSearchRequest()
                                .withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS)
                                .withESQuery(new ESMatchQuery("object.text", "tweet")));
                        return response.getTotalHits() == 2;
                    } catch (ElasticsearchClientException e) {
                        logger.warn("Caught exception while running the test", e);
                        return false;
                    }
                });
    }

    /**
     * Test case for issue #204: <a
     * href="https://github.com/dadoonet/fscrawler/issues/204">https://github.com/dadoonet/fscrawler/issues/204</a> :
     * JSON files are indexed twice
     */
    @Test
    void json_support_and_other_files() throws Exception {
        FsSettings fsSettings = createTestSettings();
        fsSettings.getFs().setJsonSupport(true);
        crawler = startCrawler(fsSettings);

        Awaitility.await()
                .atMost(MAX_WAIT_FOR_SEARCH)
                .alias("We should have 2 docs only...")
                .pollInterval(ExponentialBackoffPollInterval.exponential(Duration.ofMillis(500), Duration.ofSeconds(5)))
                .until(() -> {
                    try {
                        ESSearchResponse response = client.search(
                                new ESSearchRequest().withIndex(getCrawlerName() + FsCrawlerUtil.INDEX_SUFFIX_DOCS));
                        return response.getTotalHits() == 2;
                    } catch (ElasticsearchClientException e) {
                        logger.warn("Caught exception while running the test", e);
                        return false;
                    }
                });
    }
}
