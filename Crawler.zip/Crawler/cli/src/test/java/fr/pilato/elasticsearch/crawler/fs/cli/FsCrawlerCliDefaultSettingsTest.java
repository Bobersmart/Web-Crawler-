/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.cli;

import com.carrotsearch.randomizedtesting.jupiter.RandomizedTest;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettingsLoader;
import fr.pilato.elasticsearch.crawler.fs.settings.Server;
import fr.pilato.elasticsearch.crawler.fs.test.framework.AbstractFSCrawlerTestCase;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** We want to test FSCrawler main app */
@SuppressWarnings("removal")
class FsCrawlerCliDefaultSettingsTest extends AbstractFSCrawlerTestCase {
    private static final Logger logger = LogManager.getLogger();
    private Path metadataDir;

    @BeforeEach
    void createFsCrawlerJobDir() throws IOException {
        metadataDir = rootTmpDir.resolve(".fscrawler");
        Files.createDirectories(metadataDir);
        logger.debug("  --> Test metadata dir ready in [{}]", metadataDir);
    }

    @Test
    void settingsModifiedWithFtp() throws IOException {
        FsSettingsLoader fsSettingsLoader = new FsSettingsLoader(metadataDir);
        Path jobDir = metadataDir.resolve("modify_settings_server_ftp");
        Files.createDirectories(jobDir);

        Files.writeString(jobDir.resolve(FsSettingsLoader.SETTINGS_YAML), """
                name: "modify_settings_server_ftp"
                server:
                  hostname: "mynode.mydomain.com"
                  protocol: "ftp"
                """);
        FsSettings settings = fsSettingsLoader.read("modify_settings_server_ftp");
        Assertions.assertThat(settings.getServer().getPort()).isEqualTo(Server.PROTOCOL.FTP_PORT);
        Assertions.assertThat(settings.getServer().getUsername()).isEqualTo("anonymous");
    }

    @Test
    void settingsModifiedWithSsh() throws IOException {
        FsSettingsLoader fsSettingsLoader = new FsSettingsLoader(metadataDir);
        Path jobDir = metadataDir.resolve("modify_settings_server_ssh");
        Files.createDirectories(jobDir);

        Files.writeString(jobDir.resolve(FsSettingsLoader.SETTINGS_YAML), """
                name: "modify_settings_server_ssh"
                server:
                  hostname: "mynode.mydomain.com"
                  protocol: "ssh\"""");

        logger.info("{}", Files.readString(jobDir.resolve(FsSettingsLoader.SETTINGS_YAML)));

        FsSettings settings = fsSettingsLoader.read("modify_settings_server_ssh");
        Assertions.assertThat(settings.getServer().getPort()).isEqualTo(Server.PROTOCOL.SSH_PORT);
        Assertions.assertThat(settings.getServer().getUsername()).isNull();
    }

    @Test
    void settingsWithFsFtp() throws IOException {
        String hostname = randomHostname();
        FsSettingsLoader fsSettingsLoader = new FsSettingsLoader(metadataDir);
        Path jobDir = metadataDir.resolve("modify_settings_fs_ftp");
        Files.createDirectories(jobDir);

        Files.writeString(jobDir.resolve(FsSettingsLoader.SETTINGS_YAML), """
                name: "modify_settings_fs_ftp"
                fs:
                  provider: "ftp"
                  url: "/pub"
                  providers:
                    ftp:
                      hostname: "%s"
                """.formatted(hostname));
        FsSettings settings = fsSettingsLoader.read("modify_settings_fs_ftp");
        Assertions.assertThat(settings.getFs().getProvider()).isEqualTo("ftp");
        Assertions.assertThat(settings.getFs().getProviderConfig("ftp"))
                .isNotNull()
                .containsEntry("hostname", hostname)
                .doesNotContainKey("username")
                .doesNotContainKey("port");
    }

    @Test
    void settingsWithFsSsh() throws IOException {
        String hostname = randomHostname();
        String username = randomToken();
        FsSettingsLoader fsSettingsLoader = new FsSettingsLoader(metadataDir);
        Path jobDir = metadataDir.resolve("modify_settings_fs_ssh");
        Files.createDirectories(jobDir);

        Files.writeString(jobDir.resolve(FsSettingsLoader.SETTINGS_YAML), """
                name: "modify_settings_fs_ssh"
                fs:
                  provider: "ssh"
                  url: "/docs"
                  providers:
                    ssh:
                      hostname: "%s"
                      username: "%s"
                """.formatted(hostname, username));
        FsSettings settings = fsSettingsLoader.read("modify_settings_fs_ssh");
        Assertions.assertThat(settings.getFs().getProvider()).isEqualTo("ssh");
        Assertions.assertThat(settings.getFs().getProviderConfig("ssh"))
                .isNotNull()
                .containsEntry("hostname", hostname)
                .containsEntry("username", username)
                .doesNotContainKey("port");
    }

    private String randomHostname() {
        return randomToken() + ".example.com";
    }

    private String randomToken() {
        return RandomizedTest.randomAsciiLettersOfLengthBetween(randomizedRandomForTests, 6, 12)
                .toLowerCase(Locale.ROOT);
    }
}
