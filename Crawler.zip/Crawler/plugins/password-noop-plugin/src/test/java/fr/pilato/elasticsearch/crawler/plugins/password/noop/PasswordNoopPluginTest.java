/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.plugins.password.noop;

import com.carrotsearch.randomizedtesting.jupiter.RandomizedTest;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettingsLoader;
import fr.pilato.elasticsearch.crawler.fs.test.framework.AbstractFSCrawlerTestCase;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class PasswordNoopPluginTest extends AbstractFSCrawlerTestCase {

    @Test
    void providerNeverReturnsPasswordCandidates() throws Exception {
        FsSettings settings = FsSettingsLoader.load();
        PasswordNoopPlugin.Provider provider = new PasswordNoopPlugin.Provider();
        provider.start(settings, type -> null);

        String documentPath = RandomizedTest.randomAsciiLettersOfLengthBetween(randomizedRandomForTests, 8, 16);
        try (var session = provider.open(documentPath)) {
            Assertions.assertThat(session.next()).isEmpty();
        }
    }

    @Test
    void pluginUsesExpectedNames() {
        PasswordNoopPlugin plugin = new PasswordNoopPlugin();
        PasswordNoopPlugin.Provider provider = new PasswordNoopPlugin.Provider();

        Assertions.assertThat(plugin.getName()).isEqualTo("password-noop");
        Assertions.assertThat(provider.getType()).isEqualTo("noop");
    }
}
