/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.plugins.fs.ssh;

import com.carrotsearch.randomizedtesting.jupiter.RandomizedTest;
import fr.pilato.elasticsearch.crawler.fs.beans.FileAbstractModel;
import fr.pilato.elasticsearch.crawler.fs.framework.FsCrawlerIllegalConfigurationException;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettings;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettingsLoader;
import fr.pilato.elasticsearch.crawler.fs.test.framework.AbstractFSCrawlerTestCase;
import fr.pilato.elasticsearch.crawler.plugins.FsCrawlerExtensionFsProvider;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.sshd.server.SshServer;
import org.apache.sshd.server.config.keys.AuthorizedKeysAuthenticator;
import org.apache.sshd.server.keyprovider.SimpleGeneratorHostKeyProvider;
import org.apache.sshd.sftp.server.SftpFileSystemAccessor;
import org.apache.sshd.sftp.server.SftpSubsystemFactory;
import org.apache.sshd.sftp.server.SftpSubsystemProxy;
import org.assertj.core.api.Assertions;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

@SuppressWarnings("removal")
class FsSshPluginTest extends AbstractFSCrawlerTestCase {
    private static final Logger logger = LogManager.getLogger();
    private static final String SSH_USERNAME = "USERNAME";
    private static final String SSH_PASSWORD = "PASSWORD";
    private SshServer sshd = null;

    @BeforeEach
    void setup() throws IOException, NoSuchAlgorithmException {
        // Create a dedicated filesystem root for SFTP to avoid mixing keys with test files
        Path sftpRoot = Files.createDirectories(testTmpDir.resolve("sftp-root"));

        // Create a fake filesystem with the following structure:
        /*
        /testfile.txt
        /nested
            /foo.txt
            /bar.txt
            /buzz
                /hello.txt
                /world.txt
        /permission
            /all.txt (with all permissions)
            /none.txt (with no permissions)
        /subdir_with_space
            /hello.txt
            /world.txt
         */

        addFakeFile(sftpRoot, "testfile.txt", "I'm a test file");

        addFakeDir(sftpRoot, "nested");
        addFakeFile(sftpRoot.resolve("nested"), "foo.txt", "文件名不支持中文");
        addFakeFile(sftpRoot.resolve("nested"), "bar.txt", "bar file");

        Path buzzDir = addFakeDir(sftpRoot.resolve("nested"), "buzz");
        addFakeFile(buzzDir, "hello.txt", "hello");
        addFakeFile(buzzDir, "world.txt", "world");

        Path permissionDir = addFakeDir(sftpRoot, "permission");
        Path allFile = permissionDir.resolve("all.txt");
        if (Files.notExists(allFile)) {
            Files.writeString(allFile, "123");
        }
        allFile.toFile().setReadable(true, false);
        allFile.toFile().setWritable(true, false);
        allFile.toFile().setExecutable(true, false);
        Path noneFile = permissionDir.resolve("none.txt");
        if (Files.notExists(noneFile)) {
            Files.writeString(noneFile, "456");
        }
        noneFile.toFile().setReadable(false, false);
        noneFile.toFile().setWritable(false, false);
        noneFile.toFile().setExecutable(false, false);

        Path subdirWithSpace = addFakeDir(sftpRoot, "subdir_with_space ");
        addFakeFile(subdirWithSpace, "hello.txt", "File in dir with space at the end");
        addFakeFile(subdirWithSpace, "world.txt", "File in dir with space at the end");

        SftpSubsystemFactory factory = new SftpSubsystemFactory.Builder()
                .withFileSystemAccessor(new SftpFileSystemAccessor() {
                    @Override
                    public Path resolveLocalFilePath(SftpSubsystemProxy subsystem, Path rootDir, String remotePath)
                            throws InvalidPathException {
                        String path = remotePath;
                        if (remotePath.startsWith("/")) {
                            path = remotePath.substring(1);
                        }
                        return sftpRoot.resolve(path);
                    }
                })
                .build();

        // Create SSH key directory to isolate keys from the SFTP filesystem
        Path sshKeyDir = Files.createDirectories(testTmpDir.resolve(".ssh-keys"));

        // Generate key files for SSH tests
        SshTestHelper.generateAndSaveKeyPair(sshKeyDir);

        sshd = SshServer.setUpDefaultServer();
        sshd.setHost("localhost");
        sshd.setKeyPairProvider(new SimpleGeneratorHostKeyProvider(sshKeyDir.resolve("host.ser")));
        sshd.setPasswordAuthenticator(
                (username, password, session) -> SSH_USERNAME.equals(username) && SSH_PASSWORD.equals(password));
        sshd.setPublickeyAuthenticator(new AuthorizedKeysAuthenticator(sshKeyDir.resolve("public.key")));
        sshd.setSubsystemFactories(Collections.singletonList(factory));
        sshd.start();

        logger.info(" -> Started fake SSHD service on {}:{}", sshd.getHost(), sshd.getPort());
    }

    @AfterEach
    void shutDown() throws IOException {
        if (sshd != null) {
            sshd.stop(true);
            sshd.close();
            logger.info(" -> Stopped fake SSHD service on {}:{}", sshd.getHost(), sshd.getPort());
        }
    }

    @Test
    void sshPlugin() throws Exception {
        FsSettings fsSettings = FsSettingsLoader.load();
        fsSettings.getServer().setHostname(sshd.getHost());
        fsSettings.getServer().setPort(sshd.getPort());
        fsSettings.getServer().setUsername(SSH_USERNAME);
        fsSettings.getServer().setPassword(SSH_PASSWORD);

        FsSshPlugin.FsCrawlerExtensionFsProviderSsh sshPlugin = new FsSshPlugin.FsCrawlerExtensionFsProviderSsh();
        sshPlugin.start(fsSettings);

        try {
            sshPlugin.openConnection();

            Assertions.assertThat(sshPlugin.exists("/ThisPathDoesNotExist")).isFalse();

            testFilesInDir(sshPlugin, "/ThisPathDoesNotExist");
            testFilesInDir(
                    sshPlugin,
                    "/",
                    Assertions.tuple(false, true, "nested", "", "/", "/nested", 0L, 16877, "0", "0"),
                    Assertions.tuple(false, true, "permission", "", "/", "/permission", 0L, 16877, "0", "0"),
                    Assertions.tuple(
                            false, true, "subdir_with_space ", "", "/", "/subdir_with_space ", 0L, 16877, "0", "0"),
                    Assertions.tuple(true, false, "testfile.txt", "txt", "/", "/testfile.txt", 15L, 33188, "0", "0"));
            testFilesInDir(
                    sshPlugin,
                    "/nested",
                    Assertions.tuple(false, true, "buzz", "", "/nested", "/nested/buzz", 0L, 16877, "0", "0"),
                    Assertions.tuple(true, false, "foo.txt", "txt", "/nested", "/nested/foo.txt", 24L, 33188, "0", "0"),
                    Assertions.tuple(true, false, "bar.txt", "txt", "/nested", "/nested/bar.txt", 8L, 33188, "0", "0"));
            testFilesInDir(
                    sshPlugin,
                    "/permission",
                    Assertions.tuple(
                            true, false, "all.txt", "txt", "/permission", "/permission/all.txt", 3L, 33279, "0", "0"),
                    Assertions.tuple(
                            true,
                            false,
                            "none.txt",
                            "txt",
                            "/permission",
                            "/permission/none.txt",
                            3L,
                            32768,
                            "0",
                            "0"));
            testFilesInDir(
                    sshPlugin,
                    "/subdir_with_space ",
                    Assertions.tuple(
                            true,
                            false,
                            "hello.txt",
                            "txt",
                            "/subdir_with_space ",
                            "/subdir_with_space /hello.txt",
                            33L,
                            33188,
                            "0",
                            "0"),
                    Assertions.tuple(
                            true,
                            false,
                            "world.txt",
                            "txt",
                            "/subdir_with_space ",
                            "/subdir_with_space /world.txt",
                            33L,
                            33188,
                            "0",
                            "0"));
        } finally {
            sshPlugin.closeConnection();
        }
    }

    @Test
    void getType() {
        FsSshPlugin.FsCrawlerExtensionFsProviderSsh sshPlugin = new FsSshPlugin.FsCrawlerExtensionFsProviderSsh();
        Assertions.assertThat(sshPlugin.getType()).isEqualTo("ssh");
    }

    @Test
    void crawlerStartDefaultsSftpUrlOnPort22() {
        String hostname = randomToken() + ".example.com";
        String username = randomToken();
        FsSettings settings = FsSettingsLoader.load();
        settings.getFs().setProviders(Map.of("ssh", Map.of("hostname", hostname, "username", username)));

        FsSshPlugin.FsCrawlerExtensionFsProviderSsh sshPlugin = new FsSshPlugin.FsCrawlerExtensionFsProviderSsh();
        sshPlugin.start(settings);

        Assertions.assertThat(sshPlugin.toFileUrl("/doc.pdf"))
                .isEqualTo("sftp://" + hostname + ":" + FsSshPlugin.FsCrawlerExtensionFsProviderSsh.DEFAULT_PORT
                        + "/doc.pdf");
    }

    @Test
    void crawlerStartRequiresHostname() {
        FsSettings settings = FsSettingsLoader.load();
        FsSshPlugin.FsCrawlerExtensionFsProviderSsh sshPlugin = new FsSshPlugin.FsCrawlerExtensionFsProviderSsh();

        Assertions.assertThatThrownBy(() -> sshPlugin.start(settings))
                .isInstanceOf(FsCrawlerIllegalConfigurationException.class)
                .hasMessageContaining("fs.providers.ssh.hostname");
    }

    @Test
    void crawlerStartRequiresUsername() {
        String hostname = randomToken() + ".example.com";
        FsSettings settings = FsSettingsLoader.load();
        settings.getFs().setProviders(Map.of("ssh", Map.of("hostname", hostname)));

        FsSshPlugin.FsCrawlerExtensionFsProviderSsh sshPlugin = new FsSshPlugin.FsCrawlerExtensionFsProviderSsh();

        Assertions.assertThatThrownBy(() -> sshPlugin.start(settings))
                .isInstanceOf(FsCrawlerIllegalConfigurationException.class)
                .hasMessageContaining("fs.providers.ssh.username");
    }

    @Test
    void crawlerStartRejectsBlankUsername() {
        String hostname = randomToken() + ".example.com";
        FsSettings settings = FsSettingsLoader.load();
        settings.getFs().setProviders(Map.of("ssh", Map.of("hostname", hostname, "username", "")));

        FsSshPlugin.FsCrawlerExtensionFsProviderSsh sshPlugin = new FsSshPlugin.FsCrawlerExtensionFsProviderSsh();

        Assertions.assertThatThrownBy(() -> sshPlugin.start(settings))
                .isInstanceOf(FsCrawlerIllegalConfigurationException.class)
                .hasMessageContaining("fs.providers.ssh.username");
    }

    @Test
    void overlayWithoutPathFails() {
        String hostname = randomToken() + ".example.com";
        String username = randomToken();
        FsSettings settings = FsSettingsLoader.load();
        settings.getFs().setProviders(Map.of("ssh", Map.of("hostname", hostname, "username", username)));

        FsSshPlugin.FsCrawlerExtensionFsProviderSsh sshPlugin = new FsSshPlugin.FsCrawlerExtensionFsProviderSsh();

        Assertions.assertThatThrownBy(
                        () -> sshPlugin.start(settings, Map.of("hostname", hostname, "username", username)))
                .isInstanceOf(FsCrawlerIllegalConfigurationException.class)
                .hasMessageContaining("ssh path is missing");
    }

    private String randomToken() {
        return RandomizedTest.randomAsciiLettersOfLengthBetween(randomizedRandomForTests, 6, 12)
                .toLowerCase(Locale.ROOT);
    }

    private void testFilesInDir(FsCrawlerExtensionFsProvider plugin, String path, Tuple... values) throws Exception {
        Assertions.assertThat(plugin.exists(path)).isEqualTo(values.length > 0);
        Collection<FileAbstractModel> files = plugin.getFiles(path);
        Assertions.assertThat(files).hasSize(values.length);
        Assertions.assertThat(files)
                .extracting(
                        FileAbstractModel::isFile,
                        FileAbstractModel::isDirectory,
                        FileAbstractModel::getName,
                        FileAbstractModel::getExtension,
                        FileAbstractModel::getPath,
                        FileAbstractModel::getFullpath,
                        FileAbstractModel::getSize,
                        FileAbstractModel::getPermissions,
                        FileAbstractModel::getGroup,
                        FileAbstractModel::getOwner)
                .containsExactlyInAnyOrder(values);
    }

    private void addFakeFile(Path dir, String filename, String content) throws IOException {
        Path testFile = dir.resolve(filename);
        if (Files.notExists(testFile)) {
            Files.writeString(testFile, content);
        }
    }

    private Path addFakeDir(Path dir, String subDirname) throws IOException {
        Path subDir = dir.resolve(subDirname);
        Files.createDirectories(subDir);
        return subDir;
    }
}
