/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.plugins.fs.http;

import fr.pilato.elasticsearch.crawler.fs.beans.Doc;
import fr.pilato.elasticsearch.crawler.fs.settings.FsSettingsLoader;
import fr.pilato.elasticsearch.crawler.fs.test.framework.AbstractFSCrawlerTestCase;
import fr.pilato.elasticsearch.crawler.fs.test.framework.DisabledIfNoDocker;
import fr.pilato.elasticsearch.crawler.plugins.FsCrawlerExtensionFsProvider;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.testcontainers.containers.wait.strategy.HttpWaitStrategy;
import org.testcontainers.nginx.NginxContainer;
import org.testcontainers.utility.MountableFile;

class FsHttpPluginIT extends AbstractFSCrawlerTestCase {
    private static final Logger logger = LogManager.getLogger();
    private static final String TEXT = "Hello Foo world!";

    private void createFile(Path root, String objectName, String object) throws IOException {
        logger.info("Create fake content [{}]; [{}]", objectName, object);
        Path file = root.resolve(objectName);
        Files.writeString(file, object);
    }

    @Test
    @DisabledIfNoDocker
    void readFileFromNginx() throws Exception {
        logger.info("Starting Nginx from {}", rootTmpDir);
        Path nginxRoot = rootTmpDir.resolve("nginx-root");
        Files.createDirectories(nginxRoot);
        Files.writeString(nginxRoot.resolve("index.html"), "<html><body>Hello World!</body></html>");
        createFile(nginxRoot, "foo.txt", TEXT);
        createFile(nginxRoot, "bar.txt", "This one should be ignored.");

        try (NginxContainer container = new NginxContainer("nginx")) {
            container.waitingFor(new HttpWaitStrategy());
            container.start();
            container.copyFileToContainer(MountableFile.forHostPath(nginxRoot), "/usr/share/nginx/html");
            URL url = container.getBaseUrl("http", 80);
            logger.info("Nginx started on {}.", url);

            logger.info("Starting Test");
            try (FsCrawlerExtensionFsProvider provider = new FsHttpPlugin.FsCrawlerExtensionFsProviderHttp()) {
                provider.start(FsSettingsLoader.load(), Map.of("url", url + "/foo.txt"));
                InputStream inputStream = provider.readFile();
                String object = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
                Assertions.assertThat(object).isEqualTo(TEXT);
                Doc doc = provider.createDocument();
                Assertions.assertThat(doc.getFile().getFilename()).isEqualTo("foo.txt");
                Assertions.assertThat(doc.getFile().getFilesize()).isEqualTo(16L);
            }
        }
    }

    @Test
    void readTxtFileFromWebsite() throws Exception {
        logger.info("Starting Test");
        try (FsCrawlerExtensionFsProvider provider = new FsHttpPlugin.FsCrawlerExtensionFsProviderHttp()) {
            provider.start(FsSettingsLoader.load(), Map.of("url", "https://david.pilato.fr/robots.txt"));
            InputStream inputStream = provider.readFile();
            String object = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
            Assertions.assertThat(object).contains("User-agent: *");
            Doc doc = provider.createDocument();
            Assertions.assertThat(doc.getFile().getFilename()).isEqualTo("robots.txt");
            Assertions.assertThat(doc.getFile().getFilesize()).isEqualTo(14L);
        }
    }
}
