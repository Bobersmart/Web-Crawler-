/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.framework;

import fr.pilato.elasticsearch.crawler.fs.test.framework.AbstractFSCrawlerTestCase;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class FsMatchFilesTest extends AbstractFSCrawlerTestCase {

    @Test
    void exclude_only() {
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.doc", new ArrayList<>(), Collections.singletonList("*/*.doc")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.xls", new ArrayList<>(), Collections.singletonList("*/*.doc")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", new ArrayList<>(), Collections.singletonList("*/*.doc")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", new ArrayList<>(), Arrays.asList("*/*.doc", "*/*.xls")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", new ArrayList<>(), Collections.singletonList("*/my.d?c*.xls")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.douc.xls", new ArrayList<>(), Collections.singletonList("*/my.d?c*.xls")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/.snapshots", new ArrayList<>(), Collections.singletonList("*/.snapshots")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/doc.doc", new ArrayList<>(), Arrays.asList("*/*.pdf", "*/*.xls", "*/*.doc")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/doc.ppt", new ArrayList<>(), Arrays.asList("*/*.pdf", "*/*.xls", "*/*.doc")))
                .isTrue();
    }

    @Test
    void include_only() {
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.doc", Collections.singletonList("*/*.doc"), new ArrayList<>()))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.xls", Collections.singletonList("*/*.doc"), new ArrayList<>()))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", Collections.singletonList("*/*.doc"), new ArrayList<>()))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", Collections.singletonList("*/my.d?c*.xls"), new ArrayList<>()))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.douc.xls", Collections.singletonList("*/my.d?c*.xls"), new ArrayList<>()))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/doc.doc", Arrays.asList("*/*.pdf", "*/*.xls", "*/*.doc"), new ArrayList<>()))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/doc.ppt", Arrays.asList("*/*.pdf", "*/*.xls", "*/*.doc"), new ArrayList<>()))
                .isFalse();
    }

    @Test
    void include_exclude() {
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.doc", Collections.singletonList("*/*.xls"), Collections.singletonList("*/*.doc")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.xls", Collections.singletonList("*/*.xls"), Collections.singletonList("*/*.doc")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false,
                        "/my.doc.xls",
                        Collections.singletonList("*/*.xls"),
                        Collections.singletonList("*/*.doc")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false,
                        "/my.doc.xls",
                        Collections.singletonList("*/*.xls"),
                        Collections.singletonList("*/my.d?c*.xls")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false,
                        "/my.douc.xls",
                        Collections.singletonList("*/*.xls"),
                        Collections.singletonList("*/my.d?c*.xls")))
                .isTrue();
    }

    @Test
    void case_sensitive() {
        // Excludes
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.doc", new ArrayList<>(), Collections.singletonList("*/*.DOC")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.xls", new ArrayList<>(), Collections.singletonList("*/*.DOC")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", new ArrayList<>(), Collections.singletonList("*/*.DOC")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", new ArrayList<>(), Arrays.asList("*/*.DOC", "*/*.XLS")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", new ArrayList<>(), Collections.singletonList("*/MY.D?C*.XLS")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.douc.xls", new ArrayList<>(), Collections.singletonList("*/MY.d?C*.XLS")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/.snapshots", new ArrayList<>(), Collections.singletonList("*/.SNAPSHOTS")))
                .isFalse();

        // Includes
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.doc", Collections.singletonList("*/*.DOC"), new ArrayList<>()))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/test.xls", Collections.singletonList("*/*.DOC"), new ArrayList<>()))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", Collections.singletonList("*/*.DOC"), new ArrayList<>()))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.doc.xls", Collections.singletonList("*/MY.D?C*.XLS"), new ArrayList<>()))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false, "/my.douc.xls", Collections.singletonList("*/MY.D?C*.XLS"), new ArrayList<>()))
                .isFalse();
    }

    @Test
    void directories() {
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/folderA", new ArrayList<>(), Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderA/subfolderA",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderA/subfolderB",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderA/subfolderC",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/folderB", new ArrayList<>(), Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderB/subfolderA",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderB/subfolderB",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderB/subfolderC",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/folderC", new ArrayList<>(), Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderC/subfolderA",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderC/subfolderB",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderC/subfolderC",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/subfolderA", new ArrayList<>(), Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/subfolderB", new ArrayList<>(), Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/subfolderC", new ArrayList<>(), Collections.singletonList("/folderB/subfolder*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/folderA", new ArrayList<>(), Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderA/subfolderA",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderA/subfolderB",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderA/subfolderC",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/folderB", new ArrayList<>(), Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderB/subfolderA",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderB/subfolderB",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderB/subfolderC",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/folderC", new ArrayList<>(), Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderC/subfolderA",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderC/subfolderB",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true,
                        "/folderC/subfolderC",
                        new ArrayList<>(),
                        Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/subfolderA", new ArrayList<>(), Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/subfolderB", new ArrayList<>(), Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/subfolderC", new ArrayList<>(), Collections.singletonList("/folderB/subfolderB/*")))
                .isTrue();
    }

    /**
     * Testing with short wildcards (word documents being edited) See <a
     * href="https://github.com/dadoonet/fscrawler/issues/1794>#1794</a>
     */
    @Test
    void specialCharacters1794() {
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false,
                        "/filter test/should-exclude.docx",
                        Arrays.asList("*.pdf", "*.doc", "*.docx", "*.xsl", "*.xslx", "*.msg", "*.txt", "*.md"),
                        Arrays.asList("*.exclude", "*~*")))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        false,
                        "/filter test/~should-exclude.docx",
                        Arrays.asList("*.pdf", "*.doc", "*.docx", "*.xsl", "*.xslx", "*.msg", "*.txt", "*.md"),
                        Arrays.asList("*.exclude", "*~*")))
                .isFalse();
    }

    /**
     * Testing with short wildcards (word documents being edited) See <a
     * href="https://github.com/dadoonet/fscrawler/issues/1794>#1794</a>
     */
    @Test
    void isMatching() {
        Assertions.assertThat(FsCrawlerUtil.isMatching(
                        "/filter test/~should-exclude.docx", Collections.singletonList("*~*"), "exclusion"))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isMatching(
                        "/filter test/~should-exclude.docx", Collections.singletonList("*/~*"), "exclusion"))
                .isTrue();
        Assertions.assertThat(FsCrawlerUtil.isMatching(
                        "/filter test/should-not-exclude.docx", Collections.singletonList("*~*"), "exclusion"))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isMatching(
                        "/filter test/should-not-exclude.docx.exclude",
                        Collections.singletonList("*.exclude"),
                        "exclusion"))
                .isTrue();
    }

    /** Testing with windows separator See <a href="https://github.com/dadoonet/fscrawler/issues/1974>#1974</a> */
    @Test
    void windowsSeparator() {
        // We test with the Linux separator
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/arbets", new ArrayList<>(), Collections.singletonList("*/arbets/*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/foo/arbets", new ArrayList<>(), Collections.singletonList("*/arbets/*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "/foo", new ArrayList<>(), Collections.singletonList("*/arbets/*")))
                .isTrue();
        // We test with the Windows separator
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "\\arbets", new ArrayList<>(), Collections.singletonList("*/arbets/*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "\\foo\\arbets", new ArrayList<>(), Collections.singletonList("*/arbets/*")))
                .isFalse();
        Assertions.assertThat(FsCrawlerUtil.isIndexable(
                        true, "\\foo", new ArrayList<>(), Collections.singletonList("*/arbets/*")))
                .isTrue();
    }
}
