/*
 * Licensed to David Pilato (the "Author") under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. Author licenses this
 * file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 * Made from 🇫🇷🇪🇺 with ❤️ - 2011-2026
 */
package fr.pilato.elasticsearch.crawler.fs.framework;

import java.util.Locale;

public class Percentage {

    private double value;

    private boolean isPercentage;

    /**
     * Required by Gestalt Config when binding string settings such as {@code fs.indexed_chars} into a
     * {@link Percentage} instance.
     *
     * @param value percentage or absolute value as a string (for example {@code "80%"} or {@code "10000"})
     * @throws IllegalArgumentException if {@code value} is null or cannot be parsed
     */
    public Percentage(String value) {
        Percentage parsed = parse(value);
        if (parsed == null) {
            throw new IllegalArgumentException("Failed to parse percentage [null].");
        }
        this.value = parsed.value;
        this.isPercentage = parsed.isPercentage;
    }

    public Percentage() {
        value = 0;
        isPercentage = false;
    }

    public Percentage(double value) {
        this(value, false);
    }

    public Percentage(double value, boolean percentage) {
        this.value = value;
        this.isPercentage = percentage;
    }

    public double value() {
        return value;
    }

    public void value(double value) {
        this.value = value;
    }

    public boolean percentage() {
        return isPercentage;
    }

    public void percentage(boolean percentage) {
        this.isPercentage = percentage;
    }

    public double asDouble() {
        if (isPercentage) {
            return value / 100.0;
        } else {
            throw new UnsupportedOperationException("Can not convert to double a non percentage value");
        }
    }

    public String format() {
        return "" + value + (isPercentage ? "%" : "");
    }

    @Override
    public String toString() {
        return format();
    }

    public static Percentage parse(String sValue) {
        if (sValue == null) {
            return null;
        }
        try {
            String lowerSValue = sValue.toLowerCase(Locale.ROOT).trim();
            if (lowerSValue.endsWith("%")) {
                double value = Double.parseDouble(lowerSValue.substring(0, lowerSValue.length() - 1));
                return new Percentage(value, true);
            } else {
                double value = Double.parseDouble(lowerSValue);
                return new Percentage(value, false);
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Failed to parse percentage [" + sValue + "].");
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Percentage that = (Percentage) o;

        if (Double.compare(that.value, value) != 0) return false;
        return isPercentage == that.isPercentage;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        temp = Double.doubleToLongBits(value);
        result = (int) (temp ^ (temp >>> 32));
        result = 31 * result + (isPercentage ? 1 : 0);
        return result;
    }
}
